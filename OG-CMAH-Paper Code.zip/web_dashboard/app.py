import os
import sys
import json
import time
import random
from flask import Flask, render_template_string, Response, send_from_directory, request

app = Flask(__name__, static_folder='.', template_folder='.')
WEB_APP_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(WEB_APP_DIR)

@app.route('/')
def index():
    with open(os.path.join(WEB_APP_DIR, 'index.html'), 'r', encoding='utf-8') as f:
        html_content = f.read()
    return render_template_string(html_content)

@app.route('/css/<path:filename>')
def serve_css(filename):
    return send_from_directory(os.path.join(WEB_APP_DIR, 'css'), filename)

@app.route('/js/<path:filename>')
def serve_js(filename):
    return send_from_directory(os.path.join(WEB_APP_DIR, 'js'), filename)

@app.route('/images/<path:filename>')
def serve_images(filename):
    return send_from_directory(os.path.join(WEB_APP_DIR, 'images'), filename)

@app.route('/screenshots/<path:filename>')
def serve_screenshots(filename):
    return send_from_directory(os.path.join(WEB_APP_DIR, 'screenshots'), filename)

@app.route('/api/stream')
def sse_stream():
    ds_key = request.args.get('ds', 'ds3')

    attack_types_ds1 = ["PE Trojan.Win32", "Ransomware.WannaCry", "Backdoor.Shadow", "Benign Binary"]
    attack_types_ds2 = ["DDoS-Hulk", "PortScan", "DoS-GoldenEye", "FTP-Patator", "Benign Flow"]
    attack_types_ds3 = ["LOIC-HTTP DDoS", "HOIC Attack", "SSH-Bruteforce", "Botnet Flow", "Benign Flow"]

    attack_pool = attack_types_ds3 if ds_key == 'ds3' else (attack_types_ds2 if ds_key == 'ds2' else attack_types_ds1)

    def generate_events():
        idx = 1
        while True:
            is_threat = random.random() < 0.35
            prob = random.uniform(0.75, 0.99) if is_threat else random.uniform(0.01, 0.25)
            attack_name = random.choice(attack_pool[:-1]) if is_threat else attack_pool[-1]
            
            src_ip = f"192.168.1.{random.randint(10, 250)}" if not is_threat else f"10.0.4.{random.randint(2, 99)}"
            dst_ip = f"172.16.0.{random.randint(1, 20)}"
            src_port = random.randint(1024, 65535)
            dst_port = random.choice([80, 443, 22, 21, 8080])

            latency = round(random.uniform(0.12, 0.35), 2)
            conf = round(prob * 100, 1) if is_threat else round((1 - prob) * 100, 1)

            if is_threat:
                t_level = "CRITICAL" if conf >= 90.0 else ("HIGH" if conf >= 75.0 else "MEDIUM")
            else:
                t_level = "SAFE"

            event_data = {
                'id': idx,
                'timestamp': time.strftime("%H:%M:%S"),
                'src_ip': src_ip,
                'dst_ip': dst_ip,
                'src_port': src_port,
                'dst_port': dst_port,
                'protocol': 'TCP' if random.random() > 0.3 else 'UDP',
                'attack_name': attack_name,
                'is_threat': is_threat,
                'probability': prob,
                'confidence': conf,
                'threat_level': t_level,
                'latency_ms': latency,
                'dataset': ds_key.upper()
            }

            yield f"data: {json.dumps(event_data)}\n\n"
            idx += 1
            time.sleep(1.2)

    return Response(generate_events(), mimetype='text/event-stream')

if __name__ == '__main__':
    print("=" * 70)
    print("   CYBERGUARD AI - REAL-TIME FLASK SOC THREAT DASHBOARD   ")
    print("=" * 70)
    print("   Serving Flask Application at: http://127.0.0.1:5000   ")
    print("   Serving Flask Application at: http://localhost:5000   ")
    print("=" * 70)
    app.run(host='0.0.0.0', port=5000, debug=False)
