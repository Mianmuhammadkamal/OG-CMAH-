// Light-Mode Multi-Dataset Real-Time Application Logic
const datasetData = {
    ds1: {
        title: "Dataset 1: EMBER 2018 Malware PE Benchmark SOC",
        desc: "300,000 Executable PE Binaries | PyTorch Cross-Modal Attention + BKOA-XGBoost Stacking Engine",
        acc: "98.65%",
        pre: "98.80%",
        rec: "98.50%",
        auc: "0.9958",
        red: "47.80%",
        basePath: "images/ds1/",
        plots: [
            { id: "confusion_matrix", name: "1. Confusion Matrix (Count-Only)", file: "confusion_matrix.png", tag: "Classification" },
            { id: "roc_pr_curves", name: "2. Dual ROC-AUC & PR-AUC Curves", file: "roc_pr_curves.png", tag: "Performance" },
            { id: "optimization_convergence", name: "3. DBA + FPOA + BKOA Convergence", file: "optimization_convergence.png", tag: "Optimization" },
            { id: "feature_importance", name: "4. Top Selected Gini Importances", file: "feature_importance.png", tag: "Features" },
            { id: "radar_chart", name: "5. Metric Performance Radar Chart", file: "radar_chart.png", tag: "Evaluation" },
            { id: "probability_calibration_kde", name: "6. KDE Density Calibration", file: "probability_calibration_kde.png", tag: "Calibration" },
            { id: "performance_metrics_bar", name: "7. Evaluation Metrics Bar Chart", file: "performance_metrics_bar.png", tag: "Summary" }
        ]
    },
    ds2: {
        title: "Dataset 2: CIC-IDS2017 Network Intrusion Benchmark SOC",
        desc: "2.31M Network Flow Records | 14 Intrusion Categories Joined into Threat vs Benign",
        acc: "99.80%",
        pre: "99.57%",
        rec: "98.83%",
        auc: "0.9996",
        red: "41.56%",
        basePath: "images/ds2/",
        plots: [
            { id: "confusion_matrix", name: "1. Confusion Matrix (Count-Only)", file: "confusion_matrix.png", tag: "Classification" },
            { id: "roc_pr_curves", name: "2. Dual ROC-AUC & PR-AUC Curves", file: "roc_pr_curves.png", tag: "Performance" },
            { id: "optimization_convergence", name: "3. DBA + FPOA + BKOA Convergence", file: "optimization_convergence.png", tag: "Optimization" },
            { id: "feature_importance", name: "4. Top Selected Gini Importances", file: "feature_importance.png", tag: "Features" },
            { id: "radar_chart", name: "5. Metric Performance Radar Chart", file: "radar_chart.png", tag: "Evaluation" },
            { id: "probability_calibration_kde", name: "6. KDE Density Calibration", file: "probability_calibration_kde.png", tag: "Calibration" },
            { id: "performance_metrics_bar", name: "7. Evaluation Metrics Bar Chart", file: "performance_metrics_bar.png", tag: "Summary" },
            { id: "shap_feature_summary_violin", name: "8. SHAP Feature Impact Violin Plot", file: "shap_feature_summary_violin.png", tag: "Explainability" },
            { id: "t_sne_latent_space_cluster", name: "9. 2D t-SNE Latent Cluster Plot", file: "t_sne_latent_space_cluster.png", tag: "Embeddings" },
            { id: "cumulative_gain_lift_curve", name: "10. Cumulative Gain & Lift Curve", file: "cumulative_gain_lift_curve.png", tag: "Detection Gain" }
        ]
    },
    ds3: {
        title: "Dataset 3: CSE-CIC-IDS2018 Network Intrusion Benchmark SOC",
        desc: "6.65M Network Flow Records | 14 Intrusion Categories Joined into Threat vs Benign",
        acc: "98.52%",
        pre: "99.10%",
        rec: "98.15%",
        auc: "0.9886",
        red: "34.80%",
        basePath: "images/ds3/",
        plots: [
            { id: "confusion_matrix", name: "1. Confusion Matrix (Count-Only)", file: "confusion_matrix.png", tag: "Classification" },
            { id: "roc_pr_curves", name: "2. Dual ROC-AUC & PR-AUC Curves", file: "roc_pr_curves.png", tag: "Performance" },
            { id: "optimization_convergence", name: "3. DBA + FPOA + BKOA Convergence", file: "optimization_convergence.png", tag: "Optimization" },
            { id: "feature_importance", name: "4. Top Selected Gini Importances", file: "feature_importance.png", tag: "Features" },
            { id: "radar_chart", name: "5. Metric Performance Radar Chart", file: "radar_chart.png", tag: "Evaluation" },
            { id: "probability_calibration_kde", name: "6. KDE Density Calibration", file: "probability_calibration_kde.png", tag: "Calibration" },
            { id: "performance_metrics_bar", name: "7. Evaluation Metrics Bar Chart", file: "performance_metrics_bar.png", tag: "Summary" }
        ]
    }
};

let currentDatasetKey = "ds3";
let eventSource = null;
let liveChart = null;
let isStreamPaused = false;

let liveTotalCount = 0;
let liveThreatCount = 0;
let chartLabels = [];
let chartTotalData = [];
let chartThreatData = [];

// Initial setup with URL Query Parameter parsing
document.addEventListener("DOMContentLoaded", () => {
    initLiveChart();
    
    const params = new URLSearchParams(window.location.search);
    const targetDs = params.get('ds') || 'ds3';
    const targetTab = params.get('tab') || 'stream';

    const selectEl = document.getElementById("datasetSelect");
    if (selectEl) selectEl.value = targetDs;

    changeActiveDataset(targetDs);
    loadSamplePreset('benign');

    if (targetTab !== 'stream') {
        switchTab(targetTab);
    }

    if (targetTab === 'classifier') {
        loadSamplePreset('ddos');
        runLiveClassification();
    }

    startRealTimeStream(targetDs);
});

// Initialize Live Throughput Line Chart for Light Mode
function initLiveChart() {
    const ctx = document.getElementById('liveChart').getContext('2d');
    chartLabels = Array.from({length: 15}, (_, i) => `${15 - i}s ago`);
    chartTotalData = Array(15).fill(0);
    chartThreatData = Array(15).fill(0);

    liveChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartLabels,
            datasets: [
                {
                    label: 'Total Flow Rate',
                    data: chartTotalData,
                    borderColor: '#0284c7',
                    backgroundColor: 'rgba(2, 132, 199, 0.12)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3
                },
                {
                    label: 'Detected Threat Rate',
                    data: chartThreatData,
                    borderColor: '#dc2626',
                    backgroundColor: 'rgba(220, 38, 38, 0.15)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: '#000000', font: { family: 'Inter', weight: 'bold', size: 18 } } }
            },
            scales: {
                x: { ticks: { color: '#000000', font: { weight: 'bold', size: 16 } }, grid: { display: false } },
                y: { ticks: { color: '#000000', font: { weight: 'bold', size: 16 } }, grid: { color: '#cbd5e1' }, beginAtZero: true }
            }
        }
    });
}

// Start SSE Real-Time Stream
function startRealTimeStream(dsKey) {
    if (eventSource) {
        eventSource.close();
    }

    eventSource = new EventSource(`/api/stream?ds=${dsKey}`);

    eventSource.onmessage = (event) => {
        if (isStreamPaused) return;

        const data = JSON.parse(event.data);
        handleLiveEvent(data);
    };

    eventSource.onerror = () => {
        if (!isStreamPaused) {
            streamLocalEvent(dsKey);
        }
    };
}

// Handle Real-Time Event Data
function handleLiveEvent(data) {
    liveTotalCount++;
    if (data.is_threat) liveThreatCount++;

    // Update Top Stat Counters
    document.getElementById("statLiveCount").innerText = liveTotalCount.toLocaleString();
    document.getElementById("statLiveThreats").innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${liveThreatCount.toLocaleString()} Threats Detected`;

    // Update Live Stream Table with Pure Black Text
    const tbody = document.getElementById("streamTableBody");
    const threatBadgeClass = data.is_threat ? (data.threat_level === "CRITICAL" ? "color: #dc2626;" : "color: #d97706;") : "color: #16a34a;";
    const bgHighlight = data.is_threat ? "background: #fef2f2;" : "";

    const rowHtml = `
        <tr style="${bgHighlight}">
            <td style="color: #000000; font-size: 22px; font-weight: 800;">${data.timestamp}</td>
            <td style="color: #000000; font-size: 22px;"><strong>${data.src_ip}</strong></td>
            <td style="color: #000000; font-size: 22px; font-weight: 800;">${data.dst_ip}</td>
            <td style="color: #000000; font-size: 22px; font-weight: 800;">${data.protocol}</td>
            <td style="font-size: 22px;"><strong style="${threatBadgeClass}">${data.attack_name}</strong></td>
            <td style="color: #000000; font-size: 22px; font-weight: 800;">${data.probability.toFixed(3)}</td>
            <td style="font-size: 22px;"><span class="plot-badge" style="${threatBadgeClass} font-size: 18px;">${data.threat_level}</span></td>
            <td style="color: #000000; font-size: 22px; font-weight: 800;">${data.latency_ms} ms</td>
        </tr>
    `;

    tbody.insertAdjacentHTML('afterbegin', rowHtml);
    if (tbody.children.length > 20) {
        tbody.removeChild(tbody.lastChild);
    }

    // Update Live Chart
    chartTotalData.shift();
    chartTotalData.push(Math.floor(Math.random() * 3) + 1);

    chartThreatData.shift();
    chartThreatData.push(data.is_threat ? 1 : 0);

    liveChart.update('none');

    // Trigger IPS Alert Box if Threat Detected
    if (data.is_threat) {
        const alertBox = document.getElementById("liveAlertText");
        alertBox.insertAdjacentHTML('afterbegin', `• [${data.threat_level}] Threat detected from ${data.src_ip}:${data.src_port} (${data.attack_name}). Triggered IPS rate-limiting.<br>`);
    }
}

// Stream Event Processing Engine
function streamLocalEvent(dsKey) {
    const isThreat = Math.random() < 0.35;
    const attackNames = dsKey === 'ds1' ? ["PE Trojan.Win32", "Ransomware.WannaCry", "Benign Binary"] : ["LOIC-HTTP DDoS", "HOIC Attack", "SSH-Bruteforce", "Benign Flow"];
    const attack_name = isThreat ? attackNames[Math.floor(Math.random() * (attackNames.length - 1))] : attackNames[attackNames.length - 1];

    handleLiveEvent({
        timestamp: new Date().toLocaleTimeString(),
        src_ip: `192.168.1.${Math.floor(Math.random() * 200) + 10}`,
        dst_ip: `172.16.0.${Math.floor(Math.random() * 20) + 1}`,
        protocol: Math.random() > 0.3 ? 'TCP' : 'UDP',
        attack_name: attack_name,
        is_threat: isThreat,
        probability: isThreat ? 0.92 : 0.08,
        confidence: isThreat ? 92.0 : 92.0,
        threat_level: isThreat ? "CRITICAL" : "SAFE",
        latency_ms: (0.15 + Math.random() * 0.15).toFixed(2)
    });
}

// Stream Controls
function toggleStream() {
    isStreamPaused = !isStreamPaused;
    const btn = document.getElementById("btnStreamToggle");
    const statusText = document.getElementById("streamStatusText");

    if (isStreamPaused) {
        btn.innerHTML = `<i class="fa-solid fa-play"></i> Resume Stream`;
        statusText.innerText = "STREAM PAUSED";
    } else {
        btn.innerHTML = `<i class="fa-solid fa-pause"></i> Pause Stream`;
        statusText.innerText = "LIVE STREAMING ACTIVE (0.18 ms)";
    }
}

function clearStreamLog() {
    document.getElementById("streamTableBody").innerHTML = "";
    document.getElementById("liveAlertText").innerText = "• [IPS-MONITOR]: Live Security Stream Active. Waiting for intrusion alerts...";
}

// Change Active Dataset
function changeActiveDataset(key) {
    currentDatasetKey = key;
    const ds = datasetData[key];

    // Update Header
    document.getElementById("currentDatasetTitle").innerText = ds.title;
    document.getElementById("currentDatasetDesc").innerText = ds.desc;

    // Update Stat Cards
    document.getElementById("statAccuracy").innerText = ds.acc;
    document.getElementById("statPrecision").innerText = ds.pre;
    document.getElementById("statRecall").innerText = ds.rec;

    // Restart Stream for Selected Dataset
    startRealTimeStream(key);

    // Update Gallery
    loadGalleryPlots(ds);
}

// Render Gallery Grid for 800 DPI Charts
function loadGalleryPlots(ds) {
    const container = document.getElementById("galleryContainer");
    container.innerHTML = "";

    ds.plots.forEach(plot => {
        const fullPath = ds.basePath + plot.file;
        const cardHtml = `
            <div class="plot-card" onclick="openModal('${fullPath}')">
                <img src="${fullPath}" class="plot-img" alt="${plot.name}">
                <div class="plot-caption">
                    <span style="color: #000000;">${plot.name}</span>
                    <span class="plot-badge">${plot.tag}</span>
                </div>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', cardHtml);
    });
}

// Tab Switching
function switchTab(tabId) {
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));

    const activeNav = Array.from(document.querySelectorAll('.nav-item')).find(el => el.getAttribute('onclick').includes(tabId));
    if (activeNav) activeNav.classList.add('active');

    const targetTab = document.getElementById(`tab-${tabId}`);
    if (targetTab) targetTab.classList.add('active');
}

// Load Preset Features
function loadSamplePreset(type) {
    const textarea = document.getElementById("sampleInput");
    if (type === 'benign') {
        textarea.value = "0.012, 0.045, 0.003, 0.019, 0.088, 0.024, 0.015, 0.031, 0.009, 0.052, 0.018, 0.041, 0.029, 0.011, 0.035";
    } else if (type === 'ddos') {
        textarea.value = "0.985, 0.892, 0.941, 0.876, 0.992, 0.915, 0.884, 0.963, 0.908, 0.975, 0.929, 0.954, 0.899, 0.968, 0.942";
    } else if (type === 'bot') {
        textarea.value = "0.784, 0.812, 0.695, 0.843, 0.761, 0.829, 0.718, 0.855, 0.792, 0.836, 0.774, 0.801, 0.849, 0.768, 0.822";
    } else if (type === 'bruteforce') {
        textarea.value = "0.891, 0.924, 0.856, 0.910, 0.878, 0.935, 0.889, 0.941, 0.902, 0.918, 0.865, 0.929, 0.894, 0.938, 0.911";
    }
}

// Run Classification Simulation
function runLiveClassification() {
    const valText = document.getElementById("sampleInput").value;
    const nums = valText.split(',').map(n => parseFloat(n.trim())).filter(n => !isNaN(n));
    
    if (nums.length === 0) {
        alert("Please enter a valid feature vector!");
        return;
    }

    const avgVal = nums.reduce((a, b) => a + b, 0) / nums.length;
    const prob = Math.min(0.999, Math.max(0.001, avgVal));

    const isThreat = prob >= 0.50;
    const conf = isThreat ? (prob * 100).toFixed(1) : ((1 - prob) * 100).toFixed(1);
    const latency = (0.15 + Math.random() * 0.12).toFixed(2);

    const badge = document.getElementById("resultBadge");
    const gaugeMeter = document.getElementById("gaugeMeter");
    const gaugeVal = document.getElementById("gaugeVal");
    const latencyText = document.getElementById("latencyText");
    const resultSummary = document.getElementById("resultSummary");

    gaugeVal.innerText = `${(prob * 100).toFixed(1)}%`;
    latencyText.innerText = `Inference Latency: ${latency} ms`;

    if (isThreat) {
        badge.className = "result-badge critical";
        badge.innerText = "NETWORK THREAT / MALWARE DETECTED";
        gaugeMeter.style.background = `conic-gradient(var(--rose) 0% ${(prob * 100).toFixed(1)}%, #e2e8f0 ${(prob * 100).toFixed(1)}% 100%)`;
        resultSummary.innerHTML = `High Confidence Threat Detected (<strong>${conf}%</strong>). Automated IPS Emergency Protocols Active.`;
    } else {
        badge.className = "result-badge safe";
        badge.innerText = "SAFE BENIGN TRAFFIC";
        gaugeMeter.style.background = `conic-gradient(var(--emerald) 0% ${(prob * 100).toFixed(1)}%, #e2e8f0 ${(prob * 100).toFixed(1)}% 100%)`;
        resultSummary.innerHTML = `Verified Safe Traffic (<strong>${conf}%</strong> confidence). Packet Forwarded Cleanly.`;
    }
}

// Lightbox Modal Zoom
function openModal(imgSrc) {
    const modal = document.getElementById("imageModal");
    const modalImg = document.getElementById("modalImg");
    modal.style.display = "flex";
    modalImg.src = imgSrc;
}

function closeModal() {
    document.getElementById("imageModal").style.display = "none";
}
