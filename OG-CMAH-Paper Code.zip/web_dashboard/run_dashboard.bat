@echo off
title CyberGuard AI - Real-Time Flask SOC Threat Dashboard
echo Launching CyberGuard AI Real-Time Flask Web Dashboard...
start "" "http://127.0.0.1:5000"
python app.py
pause
