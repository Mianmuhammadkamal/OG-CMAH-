# Dataset Class-Wise Distribution & Complete Hyperparameter Specifications

This document provides the complete class-wise sample breakdown, **80:20 Train-Test split distribution**, and **full hyperparameter configurations** across all components of the proposed architecture.

---

## Table A: Overall Dataset Summary & Split Ratios

| Dataset Name | Domain / Benchmark | Total Samples | Train Set (80%) | Test Set (20%) |
| :--- | :--- | :---: | :---: | :---: |
| **Dataset 1** | EMBER 2018 PE Malware Benchmark | 250,000 | 200,000 | 50,000 |
| **Dataset 2** | CIC-IDS2017 Network Intrusion | 250,000 | 200,000 | 50,000 |
| **Dataset 3** | NSL-KDD / UNSW-NB15 Benchmark | 250,000 | 200,000 | 50,000 |

---

## Table B: Detailed Class-Wise Sample Breakdown

| Dataset | Class Category | Total Count | Train Count (80%) | Test Count (20%) | Class Ratio (%) |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **Dataset 1 (EMBER)** | Benign PE (Class 0) | 125,000 | 100,000 | 25,000 | 50.00% |
| **Dataset 1 (EMBER)** | Malware PE (Class 1) | 125,000 | 100,000 | 25,000 | 50.00% |
| **Dataset 2 (CIC-IDS2017)** | Benign Traffic (Class 0) | 219,238 | 175,390 | 43,848 | 87.70% |
| **Dataset 2 (CIC-IDS2017)** | Attack Traffic (Class 1) | 30,762 | 24,610 | 6,152 | 12.30% |
| **Dataset 3 (NSL-KDD)** | Normal Traffic (Class 0) | 125,000 | 100,000 | 25,000 | 50.00% |
| **Dataset 3 (NSL-KDD)** | Intrusion Traffic (Class 1) | 125,000 | 100,000 | 25,000 | 50.00% |

---

## Table C: PyTorch Cross-Modal Attention Fusion Network Hyperparameters

| Hyperparameter Component | Configured Value | Functional Description |
| :--- | :---: | :--- |
| **Feature Embedding Dimension** | `128` | Projects raw feature groups into dense 128-dim latent space |
| **Multi-Head Attention Heads** | `4 Heads` | Computes cross-modal multihead self-attention across feature blocks |
| **Attention Groups / Sub-spaces** | `4 Groups` | Splits high-dimensional features into 4 modalities for cross-attention |
| **Dropout Rate** | `0.15` (15%) | Regularizes projections and feed-forward layers against overfitting |
| **Layer Normalization** | `Enabled` | Stabilizes layer activations and accelerates training convergence |
| **Optimizer** | `AdamW` | Adam with decoupled weight decay regularization |
| **Learning Rate Schedule** | `1.5e-3` (CosineAnnealingLR) | Decays learning rate smoothly over 100 epochs |
| **Weight Decay** | `1.0e-4` | L2 penalty coefficient for model parameter regularization |
| **Loss Function** | `BCEWithLogitsLoss` | Binary cross-entropy with logit smoothing (0.96 label scaling) |
| **Batch Size & Epochs** | `Batch Size: 512, Epochs: 100` | Optimized mini-batch training configuration |

---

## Table D: Black-winged Kite Optimization (BKOA) Swarm Hyperparameters

| Target Hyperparameter | Search Range Bounds | Optimal Selected Value | Description |
| :--- | :---: | :---: | :--- |
| **Number of Trees (`n_estimators`)** | `[150, 250]` | `200` Trees | Total boosting rounds in gradient ensemble |
| **Maximum Tree Depth (`max_depth`)** | `[6, 9]` | `8` Levels | Controls maximum depth per decision tree |
| **Learning Rate (`learning_rate`)** | `[0.05, 0.10]` | `0.08` | Shrinkage step size for boosting updates |
| **Subsample Ratio (`subsample`)** | `[0.80, 0.95]` | `0.90` (90%) | Fraction of training instances sampled per tree |
| **Feature Colsample (`colsample_bytree`)** | `[0.80, 0.95]` | `0.85` (85%) | Fraction of feature columns sampled per tree |
| **Minimum Child Weight** | `[1, 3]` | `2` | Minimum sum of instance weight needed in a child node |
| **Gamma (Min Loss Reduction)** | `[0.0, 0.05]` | `0.01` | Minimum loss reduction required for split partitioning |

---

## Table E: Meta-Ensemble Stacking Classifier Specifications

| Model Layer | Configured Hyperparameters | Execution Environment |
| :--- | :--- | :--- |
| **Primary Meta-Classifier (XGBoost)** | `tree_method="hist"`, `max_bin=128`, `n_jobs=4`, `eval_metric="logloss"` | Hist-binned CPU Execution |
| **Auxiliary Classifier (ExtraTrees)** | `n_estimators=100`, `max_depth=12`, `random_state=42`, `n_jobs=4` | Parallel Random Forest Sub-trees |
| **Feature Selection Engine (Step 2)** | DBA-FPOA Swarm Optimization + Random Forest Gini Importance | Selects Top 1200 / 45 Features |
| **BKOA Search Swarm Settings** | `n_kites=4`, `n_iterations=3`, `fitness_eval_sample=8000` | Memory-Optimized Swarm Search |
| **Threat Intelligence Engine (Step 4)** | Decision Threshold=`0.50`, High Confidence Cutoff=`90.0%` | Rule-Engine Threat Assessment |
