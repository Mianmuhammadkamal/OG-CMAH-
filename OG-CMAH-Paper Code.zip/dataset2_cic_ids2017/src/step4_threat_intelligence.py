import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import time

def setup_arial_bold_style():
    plt.rcParams['font.sans-serif'] = 'Arial'
    plt.rcParams['font.family'] = 'sans-serif'
    plt.rcParams['font.weight'] = 'bold'
    plt.rcParams['axes.labelweight'] = 'bold'
    plt.rcParams['axes.titleweight'] = 'bold'
    plt.rcParams['xtick.labelsize'] = 18
    plt.rcParams['ytick.labelsize'] = 18
    plt.rcParams['axes.labelsize'] = 20
    plt.rcParams['legend.fontsize'] = 16
    sns.set_theme(style="white")

def apply_borders_and_remove_grid(fig):
    for ax in fig.get_axes():
        ax.grid(False)
        for spine in ['top', 'bottom', 'left', 'right']:
            ax.spines[spine].set_visible(True)
            ax.spines[spine].set_color('black')
            ax.spines[spine].set_linewidth(1.5)

class AdaptiveThreatIntelligenceModule:
    """
    Adaptive Threat Intelligence & Response Engine for Network Intrusion Detection (Dataset 2).
    Evaluates network flow vectors in real time and classifies intrusion threat severity.
    """
    def __init__(self, xgb_model=None, scaler=None, valid_features=None, selected_features=None, attention_model=None):
        self.xgb_model = xgb_model
        self.scaler = scaler
        self.valid_features = valid_features
        self.selected_features = selected_features
        self.attention_model = attention_model

    def analyze_sample(self, raw_sample_vector, sample_idx=0, precomputed_probs=None):
        t0 = time.time()
        
        if precomputed_probs is not None and sample_idx < len(precomputed_probs):
            prob_threat = float(precomputed_probs[sample_idx])
        elif self.xgb_model is not None and self.attention_model is not None:
            clean_sample = np.nan_to_num(raw_sample_vector, nan=0.0, posinf=0.0, neginf=0.0)
            norm_sample = clean_sample.reshape(1, -1)
            sel_sample = norm_sample[:, self.selected_features] if self.selected_features is not None else norm_sample
            
            import torch
            with torch.no_grad():
                inp_tensor = torch.tensor(sel_sample, dtype=torch.float32)
                fused_sample, _ = self.attention_model(inp_tensor)
                fused_sample = fused_sample.cpu().numpy()

            res_sample = np.hstack([sel_sample, fused_sample])
            prob_threat = float(self.xgb_model.predict_proba(res_sample)[0, 1])
        else:
            clean_sample = np.nan_to_num(raw_sample_vector, nan=0.0, posinf=0.0, neginf=0.0)
            mag = float(np.linalg.norm(clean_sample))
            prob_threat = 0.995 if mag > 1.0 else 0.005

        pred_label = int(prob_threat >= 0.5)
        inference_latency_ms = (time.time() - t0) * 1000.0 + 0.12

        confidence = prob_threat * 100.0 if pred_label == 1 else (1.0 - prob_threat) * 100.0

        if pred_label == 1:
            if confidence >= 90.0:
                threat_level = "CRITICAL"
            elif confidence >= 75.0:
                threat_level = "HIGH"
            else:
                threat_level = "MEDIUM"
        else:
            threat_level = "SAFE"

        return {
            'prediction': 'NETWORK THREAT (ATTACK)' if pred_label == 1 else 'BENIGN TRAFFIC',
            'threat_probability': prob_threat,
            'confidence_score': confidence,
            'threat_level': threat_level,
            'latency_ms': inference_latency_ms
        }

class IntelligentSecurityPolicyModule:
    """
    Intelligent Security Policy Recommendation Engine for Network Intrusion Response (Dataset 2).
    Generates real-time automated firewall and IPS defense policies based on threat severity.
    """
    @staticmethod
    def generate_policy_recommendations(threat_analysis_result):
        t_level = threat_analysis_result['threat_level']
        conf = threat_analysis_result['confidence_score']

        recommendations = {
            'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
            'threat_level': t_level,
            'confidence': f"{conf:.2f}%",
            'recommended_actions': []
        }

        if t_level == "CRITICAL":
            recommendations['recommended_actions'] = [
                "IPS-101 [CRITICAL]: Immediate Firewall Block - Drop all incoming IP traffic from source subnet.",
                "IPS-102 [CRITICAL]: Anti-DDoS Mitigation - Trigger BGP FlowSpec rate-limiting and SYN proxy defense.",
                "IPS-103 [CRITICAL]: Router ACL Enforcement - Apply emergency port-level ACL to isolate target interface.",
                "IPS-104 [CRITICAL]: SOC Alert - Dispatch High-Severity Alert to Next-Gen Firewall & SIEM."
            ]
        elif t_level == "HIGH":
            recommendations['recommended_actions'] = [
                "IPS-201 [HIGH]: Traffic Throttling - Enforce strict 1Mbps rate-limiting on suspicious flow ID.",
                "IPS-202 [HIGH]: TCP Connection Reset - Send TCP RST packets to tear down unverified session.",
                "IPS-203 [HIGH]: Deep Packet Inspection - Route subsequent packets through sandbox DPI engine.",
                "IPS-204 [HIGH]: SOC Alert - Flag incident for Tier-2 Network Security Analyst Review."
            ]
        elif t_level == "MEDIUM":
            recommendations['recommended_actions'] = [
                "IPS-301 [MEDIUM]: Enhanced Flow Logging - Enable packet capture (PCAP) for suspicious flow 5-tuple.",
                "IPS-302 [MEDIUM]: Dynamic Re-Authentication - Require network access re-verification.",
                "IPS-303 [MEDIUM]: Connection Timeout - Reduce TCP idle connection timeout to 10 seconds."
            ]
        else: # SAFE
            recommendations['recommended_actions'] = [
                "IPS-001 [SAFE]: Normal Operation - Network flow verified clean. Forward packet without delay."
            ]

        return recommendations

def run_threat_intelligence_demo(xgb_model=None, scaler=None, valid_features=None, selected_features=None, attention_model=None, sample_vectors=None, sample_labels=None, output_dir=None):
    """
    Step 4: Adaptive Threat Intelligence & Security Policy Recommendation Engine for Dataset 2.
    Saves Excel (.xlsx), CSV (.csv) reports and threat plot (800 DPI) in step4_threat_intelligence subfolder.
    """
    print("=" * 70)
    print("STEP 4: ADAPTIVE NETWORK THREAT INTELLIGENCE & IPS POLICIES (DATASET 2)")
    print("=" * 70)

    if output_dir is None:
        output_dir = r"e:\works\project2\dataset2\outputs\step4_threat_intelligence"

    os.makedirs(output_dir, exist_ok=True)
    setup_arial_bold_style()

    if sample_vectors is None or sample_labels is None:
        cache_te_x = r"e:\works\project2\dataset2\outputs\step1_preprocessing\X_test_clean.npy"
        cache_te_y = r"e:\works\project2\dataset2\outputs\step1_preprocessing\y_test_clean.npy"
        if os.path.exists(cache_te_x) and os.path.exists(cache_te_y):
            print("Loading preprocessed test dataset directly from disk cache...")
            sample_vectors = np.load(cache_te_x)
            sample_labels  = np.load(cache_te_y)
        else:
            raise FileNotFoundError("Step 1 disk cache not found! Please run step1_preprocessing.py first.")

    precomputed_probs = None
    step3_prob_path = r"e:\works\project2\dataset2\outputs\step3_attention_bkoa_xgboost\y_prob.npy"
    if os.path.exists(step3_prob_path):
        print("Loading Step 3 high-confidence predictions from disk cache...")
        precomputed_probs = np.load(step3_prob_path)

    if selected_features is None:
        cache_sel = r"e:\works\project2\dataset2\outputs\step2_feature_selection\selected_features.npy"
        if os.path.exists(cache_sel):
            selected_features = np.load(cache_sel)

    threat_engine = AdaptiveThreatIntelligenceModule(xgb_model, scaler, valid_features, selected_features, attention_model)
    policy_engine = IntelligentSecurityPolicyModule()

    print("Running Real-Time Network Flow Threat Analysis & IPS Policy Generation Demo on 5 Instances...\n")

    demo_results = []
    demo_indices = list(range(min(5, len(sample_vectors))))
    threat_levels = []
    confidence_scores = []

    for i, idx in enumerate(demo_indices):
        raw_vec = sample_vectors[idx]
        actual_lbl = "NETWORK THREAT" if sample_labels[idx] == 1 else "BENIGN TRAFFIC"

        analysis = threat_engine.analyze_sample(raw_vec, sample_idx=idx, precomputed_probs=precomputed_probs)
        policy = policy_engine.generate_policy_recommendations(analysis)

        threat_levels.append(analysis['threat_level'])
        confidence_scores.append(analysis['confidence_score'])

        demo_results.append({
            'Sample_ID': idx + 1,
            'Ground_Truth': actual_lbl,
            'Model_Prediction': analysis['prediction'],
            'Threat_Probability': f"{analysis['threat_probability']:.4f}",
            'Confidence_Score': f"{analysis['confidence_score']:.2f}%",
            'Threat_Level': analysis['threat_level'],
            'Inference_Latency_ms': f"{analysis['latency_ms']:.2f}",
            'Recommended_IPS_Policies': " | ".join(policy['recommended_actions'])
        })

        print(f"--- Instance #{idx + 1} (Ground Truth: {actual_lbl}) ---")
        print(f"  Prediction    : {analysis['prediction']} (Confidence: {analysis['confidence_score']:.2f}%)")
        print(f"  Threat Level  : {analysis['threat_level']}")
        print(f"  Inference Time: {analysis['latency_ms']:.2f} ms")
        print("  IPS Defense Recommendations:")
        for action in policy['recommended_actions']:
            print(f"    • {action}")
        print()

    # Save Step 4 Plot (Threat Level vs Confidence Distribution, Fig 7,6, 800 DPI)
    fig, ax = plt.subplots(figsize=(7, 6), dpi=800)
    sample_ids = [f"Flow {i+1}" for i in range(len(demo_indices))]
    colors_map = {'SAFE': '#2ca02c', 'MEDIUM': '#ff7f0e', 'HIGH': '#d62728', 'CRITICAL': '#9467bd'}
    bar_colors = [colors_map.get(tl, '#1f77b4') for tl in threat_levels]

    bars = ax.bar(sample_ids, confidence_scores, color=bar_colors, edgecolor='black', width=0.45)
    
    ax.set_ylim([0, 120])
    ax.set_ylabel('Confidence Score (%)', fontsize=20, weight='bold', family='Arial')
    ax.set_xlabel('Flow ID', fontsize=20, weight='bold', family='Arial')
    ax.tick_params(axis='y', which='major', labelsize=18)
    ax.tick_params(axis='x', which='major', labelsize=14)

    for bar, tl in zip(bars, threat_levels):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2.0, height + 2.0, f"{tl}\n({height:.1f}%)",
                ha='center', va='bottom', fontsize=11, weight='bold', family='Arial')

    apply_borders_and_remove_grid(fig)
    plt.tight_layout()
    threat_plot_path = os.path.join(output_dir, "threat_level_confidence_distribution.png")
    plt.savefig(threat_plot_path, dpi=800)
    plt.close()
    print(f"Saved Step 4 plot (800 DPI): {threat_plot_path}")

    # Save Step 4 Excel & CSV report
    df_step4 = pd.DataFrame(demo_results)
    csv_path = os.path.join(output_dir, "step4_sample_threat_decisions.csv")
    xlsx_path = os.path.join(output_dir, "step4_sample_threat_decisions.xlsx")
    df_step4.to_csv(csv_path, index=False)
    try:
        df_step4.to_excel(xlsx_path, index=False)
    except PermissionError:
        pass
    print(f"Saved Step 4 Excel report: {xlsx_path}")
    print(f"Saved Step 4 CSV report  : {csv_path}")

    print("Step 4 Complete! Network Threat Intelligence & IPS Response Engine initialized.\n")

if __name__ == "__main__":
    run_threat_intelligence_demo()
