import os
import sys
import time

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from step1_preprocessing import load_and_preprocess_dataset2
from step2_feature_selection import select_malware_features_dba_fpoa
from step3_attention_bkoa_xgboost import execute_step3_attention_bkoa_xgboost
from step4_threat_intelligence import run_threat_intelligence_demo
from step5_evaluation_plots import evaluate_and_generate_plots

def run_full_dataset2_pipeline():
    """
    Master Runner for Dataset 2 (CIC-IDS2017 Network Intrusion Benchmark Dataset).
    Executes 5 modular steps sequentially and outputs all Excel reports, CSVs, and 800 DPI graphs.
    """
    print("=" * 80)
    print("      DATASET 2 (CIC-IDS2017 NETWORK INTRUSION BENCHMARK) PIPELINE      ")
    print("=" * 80)
    start_total_time = time.time()

    base_dir = os.path.dirname(__file__)
    ds_dir = os.path.join(base_dir, "dataset")
    out_dir = os.path.join(base_dir, "outputs")

    step1_dir = os.path.join(out_dir, "step1_preprocessing")
    step2_dir = os.path.join(out_dir, "step2_feature_selection")
    step3_dir = os.path.join(out_dir, "step3_attention_bkoa_xgboost")
    step4_dir = os.path.join(out_dir, "step4_threat_intelligence")
    step5_dir = os.path.join(out_dir, "step5_evaluation")

    # Step 1: Preprocessing & Log1p MinMaxScaler Normalization
    X_tr_clean, y_tr, X_te_clean, y_te, scaler, valid_features = load_and_preprocess_dataset2(
        ds_dir=ds_dir, output_dir=step1_dir, max_train_samples=300000, max_test_samples=50000
    )

    # Step 2: Feature Selection via DBA + FPOA Metaheuristics
    selected_features, dba_hist, fpoa_hist, importances = select_malware_features_dba_fpoa(
        X_train=X_tr_clean, y_train=y_tr, output_dir=step2_dir, target_features_count=45
    )

    # Filter preprocessed datasets to selected features
    X_tr_sel = X_tr_clean[:, selected_features]
    X_te_sel = X_te_clean[:, selected_features]

    # Step 3: Cross-Modal Attention Fusion + BKOA Hyperparameter Optimization + Stacking
    X_tr_fused, X_te_fused, model_xgb, y_pred, y_prob, best_params, bkoa_hist, attn_model, train_losses = execute_step3_attention_bkoa_xgboost(
        X_tr_sel=X_tr_sel, y_tr=y_tr, X_te_sel=X_te_sel, y_te=y_te, output_dir=step3_dir, embed_dim=128, num_heads=4, epochs=30, lr=5e-4
    )

    # Step 4: Adaptive Threat Intelligence & Security Policy Recommendation Engine
    run_threat_intelligence_demo(
        xgb_model=model_xgb, scaler=scaler, valid_features=valid_features,
        selected_features=selected_features, attention_model=attn_model,
        sample_vectors=X_te_clean, sample_labels=y_te, output_dir=step4_dir
    )

    # Step 5: Comprehensive Performance Evaluation & 7 Publication Plots (800 DPI)
    evaluate_and_generate_plots(
        y_true=y_te, y_pred=y_pred, y_prob=y_prob,
        dba_history=dba_hist, fpoa_history=fpoa_hist,
        attention_loss_history=train_losses, bkoa_history=bkoa_hist,
        feature_importances=importances, orig_feat_count=X_tr_clean.shape[1],
        sel_feat_count=len(selected_features), output_dir=step5_dir
    )

    total_time = time.time() - start_total_time
    print("=" * 80)
    print(f"Dataset 2 Proposal Execution Complete! Total Time: {total_time/60.0:.2f} minutes.")
    print(f"All reports, Excel spreadsheets, and 800 DPI graphs saved inside: {out_dir}")
    print("=" * 80)

if __name__ == "__main__":
    run_full_dataset2_pipeline()
