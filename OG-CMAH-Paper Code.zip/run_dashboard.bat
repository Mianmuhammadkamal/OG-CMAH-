@echo off
title CyberGuard-AI Threat Dashboard
echo ======================================================================
echo   STARTING CYBERGUARD-AI REAL-TIME FLASK SOC DASHBOARD
echo ======================================================================
cd web_dashboard
start http://127.0.0.1:5000
python app.py
pause
