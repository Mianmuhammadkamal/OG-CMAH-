# CyberGuard-AI: Multi-Modal Deep Attention Network with Swarm Optimization for Real-Time Threat Intelligence and Intrusion Prevention

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-ee4c2c.svg)](https://pytorch.org/)
[![XGBoost](https://img.shields.io/badge/XGBoost-1.7+-green.svg)](https://xgboost.readthedocs.io/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Official source code, reproducible pipelines, and interactive deployment artifacts for the manuscript submitted for peer review.

---

## 📌 1. Architectural Overview & Workflow

CyberGuard-AI is an end-to-end framework designed for multi-modal cyber threat detection, automated intelligence classification, and dynamic security policy synthesis across large-scale enterprise benchmarks (**EMBER 2018**, **CIC-IDS2017**, and **CSE-CIC-IDS2018**).

```
                      +-------------------------------------------------------------+
                      |               RAW MULTI-MODAL CYBER DATASET                 |
                      |   (PE Static/Dynamic, CIC-IDS2017 Flows, CSE-CIC-IDS2018)   |
                      +-------------------------------------------------------------+
                                                     |
                                                     v
                                       [Step 1: Adaptive Preprocessing]
                                       - Zero-leakage 80:20 Train-Test split
                                       - Log1p scaling & MinMaxScaler normalization
                                                     |
                                                     v
                                  [Step 2: Swarm Feature Selection (DBA-FPOA)]
                                  - Detective Behavior Algorithm (Exploration)
                                  - Falco Peregrinus Optimization (Exploitation)
                                  - Random Forest Gini Importance Guidance
                                                     |
                                                     v
                                 [Step 3: Deep Cross-Modal Attention & BKOA]
                                 - Multi-Head Attention Network (Embed dim: 128, Heads: 4)
                                 - Latent Representation Stacking
                                 - Black-Winged Kite Optimization for XGBoost Hyperparameters
                                                     |
                                                     v
                                   [Step 4: ATIRM & ISPRM Threat Intelligence]
                                   - Adaptive Threat Intelligence Classification
                                   - Intelligent Security Policy Recommendation Engine
                                   - Rule-based Firewall / IPS Mitigation Synthesis
                                                     |
                                                     v
                                    [Step 5: High-Precision Evaluation Suite]
                                    - 10 High-Resolution Arial Bold Metrics Plots
                                    - Grouped Comparison Charts & Error Rate Comparisons
                                    - Automated Microsoft Word (.docx) Report Generation
                                                     |
                                                     v
                                [Interactive Flask SOC Real-Time Dashboard (5000)]
```

---

## 📂 2. Submission Package Directory Structure

```
journal_submission_package/
│
├── README.md                                  <- Comprehensive documentation & replication manual
├── requirements.txt                           <- Python dependency specifications
├── environment.yml                            <- Conda virtual environment definition
├── master_run_all.py                          <- Unified command-line runner for all experiments
├── run_dashboard.bat                          <- 1-Click launcher for Web SOC Dashboard
│
├── dataset1_ember_malware/                    <- EMBER 2018 Malware PE Pipeline
│   ├── run_dataset1_pipeline.py               <- Master pipeline script
│   ├── src/
│   │   ├── step1_preprocessing.py             <- Normalization & data loading
│   │   ├── step2_feature_selection.py         <- DBA-FPOA Swarm Optimization
│   │   ├── step3_attention_bkoa_xgboost.py    <- Cross-Modal Attention + BKOA + XGBoost
│   │   ├── step4_threat_intelligence.py       <- ATIRM Threat Intelligence & ISPRM Policies
│   │   └── step5_evaluation_plots.py          <- 10 Publication-grade evaluation charts
│   └── comparison_results/
│       ├── comparison_results.docx            <- Evaluation document with Table 1 & charts
│       ├── comparison_results_table.md        <- Markdown evaluation table
│       ├── model_accuracy_comparison.png      <- Model accuracy bar plot
│       └── model_fpr_comparison.png           <- Model false positive rate bar plot
│
├── dataset2_cic_ids2017/                      <- CIC-IDS2017 Network Intrusion Pipeline
│   ├── run_dataset2_pipeline.py               <- Master pipeline script
│   ├── src/
│   │   ├── step1_preprocessing.py
│   │   ├── step2_feature_selection.py
│   │   ├── step3_attention_bkoa_xgboost.py
│   │   ├── step4_threat_intelligence.py
│   │   └── step5_evaluation_plots.py
│   └── comparison_results/
│       ├── comparison_results.docx            <- Evaluation document with Table 2 & charts
│       ├── dataset2_model_metrics_grouped.png <- Grouped metrics plot (figsize 7x6)
│       └── dataset2_fpr_fnr_error_comparison.png
│
├── dataset3_cse_cic_ids2018/                  <- CSE-CIC-IDS2018 Intrusion Pipeline
│   ├── run_dataset3_pipeline.py               <- Master pipeline script
│   ├── src/
│   │   ├── step1_preprocessing.py
│   │   ├── step2_feature_selection.py
│   │   ├── step3_attention_bkoa_xgboost.py
│   │   ├── step4_threat_intelligence.py
│   │   └── step5_evaluation_plots.py
│   └── comparison_results/
│       ├── comparison_results.docx            <- Evaluation document with Table 3 & charts
│       ├── dataset3_model_metrics_grouped.png <- Grouped metrics plot (figsize 7x6)
│       └── dataset3_fpr_fnr_error_comparison.png
│
├── web_dashboard/                             <- Real-Time Flask Threat Intelligence Dashboard
│   ├── app.py                                 <- Flask backend with live SSE streaming
│   ├── index.html                             <- Modern HTML5 SOC interface
│   ├── run_dashboard.bat                      <- Batch launcher
│   ├── css/styles.css                         <- High-contrast responsive styling
│   ├── js/app.js                              <- Real-time Chart.js & threat telemetry engine
│   ├── screenshots/                           <- Full-page 1080p dashboard captures
│   └── images/                                <- Static pipeline visual assets
│
└── documentation_and_reports/                 <- Complete Word & Markdown Documentation
    ├── dataset_classwise_sample_distribution.docx  <- Class sample counts & 80:20 splits
    ├── dataset_classwise_sample_distribution.md    <- Markdown sample distribution
    ├── dataset1_ember_comparison_results.docx     <- Dataset 1 report
    ├── dataset2_cic_ids2017_comparison_results.docx <- Dataset 2 report
    └── dataset3_cse_cic_ids2018_comparison_results.docx <- Dataset 3 report
```

---

## ⚙️ 3. Installation & Environment Setup

### Option A: Using Conda (Recommended)
```bash
# 1. Create virtual environment from environment.yml
conda env create -f environment.yml

# 2. Activate environment
conda activate cyberguard_ai
```

### Option B: Using Standard Python Virtual Environment (`venv`)
```bash
# 1. Create a Python 3.10+ virtual environment
python -m venv venv

# 2. Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

# 3. Upgrade pip and install dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 📥 4. Benchmark Datasets & Public Download Sources

Due to file size constraints of journal submission portals, raw datasets should be acquired from their official repositories and placed in their respective `dataset/` subfolders:

1. **Dataset 1: EMBER 2018 (Malware PE Benchmark)**
   - *Source*: [Endgame EMBER GitHub](https://github.com/endgameinc/ember)
   - *Target Directory*: `dataset1_ember_malware/dataset/`
   - *Files*: `X_train.dat`, `y_train.dat`, `X_test.dat`, `y_test.dat`, `metadata.csv`

2. **Dataset 2: CIC-IDS2017 (Canadian Institute for Cybersecurity)**
   - *Source*: [UNB CIC-IDS2017 Dataset Portal](https://www.unb.ca/cic/datasets/ids-2017.html)
   - *Target Directory*: `dataset2_cic_ids2017/dataset/`
   - *Files*: `Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv`, etc.

3. **Dataset 3: CSE-CIC-IDS2018 (AWS & CIC Traffic Benchmark)**
   - *Source*: [UNB CSE-CIC-IDS2018 Dataset Portal](https://www.unb.ca/cic/datasets/ids-2018.html)
   - *Target Directory*: `dataset3_cse_cic_ids2018/dataset/`
   - *Files*: 10 CSV files covering DoS, DDoS, Botnet, Infiltration, Brute Force, and Web Attacks.

---

## 🚀 5. Execution & Reproduction Guide

### Option 1: Master Interactive CLI
Run the unified master runner script from the root directory:
```bash
python master_run_all.py
```
This presents an interactive menu to run any individual pipeline, launch the web dashboard, or execute all pipelines consecutively.

### Option 2: Command-Line Flags
```bash
# Run Dataset 1 Pipeline (EMBER 2018)
python master_run_all.py --dataset 1

# Run Dataset 2 Pipeline (CIC-IDS2017)
python master_run_all.py --dataset 2

# Run Dataset 3 Pipeline (CSE-CIC-IDS2018)
python master_run_all.py --dataset 3

# Execute all 3 dataset pipelines sequentially
python master_run_all.py --all

# Launch Web SOC Dashboard
python master_run_all.py --dashboard
```

### Option 3: Individual Dataset Pipeline Execution
You can also run any pipeline directly from its subfolder:
```bash
cd dataset3_cse_cic_ids2018
python run_dataset3_pipeline.py
```

---

## 🌐 6. Real-Time SOC Threat Dashboard

CyberGuard-AI includes an interactive web dashboard for real-time intrusion monitoring and automated IPS policy generation:

1. **Start the server**:
   ```bash
   cd web_dashboard
   python app.py
   ```
   *(Or double-click `run_dashboard.bat` on Windows)*

2. **Open in browser**:
   Navigate to: **`http://localhost:5000`**

3. **Features**:
   - **Tab 1: Live Real-Time Stream**: Live telemetry streaming via Server-Sent Events (SSE).
   - **Tab 2: Threat Simulator**: Real-time interactive vector testing and instant inference.
   - **Tab 3: Attack Visualizations**: High-resolution gallery of all 10 evaluation plots.
   - **Tab 4: IPS Security Policies**: Dynamic synthesis of rule-based firewall/IPS policies.

---

## 📊 7. Summary of Comparative Benchmark Performance

### Table 1: Comparative Evaluation on Dataset 1 (EMBER 2018)
| Model | Accuracy (%) | Precision (%) | Recall (%) | F1-Score (%) | FPR (%) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| Random Forest | 95.80 | 95.90 | 95.70 | 95.80 | 4.10 |
| Decision Tree | 91.20 | 91.40 | 91.00 | 91.20 | 8.60 |
| SVM | 93.40 | 93.60 | 93.10 | 93.35 | 6.40 |
| MLP | 96.10 | 96.30 | 95.90 | 96.10 | 3.70 |
| Standard XGBoost | 97.40 | 97.60 | 97.20 | 97.40 | 2.40 |
| **Proposed (CyberGuard-AI)** | **99.85** | **99.88** | **99.82** | **99.85** | **0.12** |

### Table 2: Comparative Evaluation on Dataset 2 (CIC-IDS2017)
| Model | Accuracy (%) | Precision (%) | Recall (%) | F1-Score (%) | TNR (%) | FPR (%) | FNR (%) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| SHAP | 99.91 | 99.88 | 99.95 | 99.91 | 99.88 | 0.12 | 0.05 |
| DNN | - | 98.27 | 98.22 | 98.18 | - | - | - |
| 1D CNN | 99.99 | 99.99 | 99.98 | 99.98 | - | - | - |
| BI-LSTM-GMM | 86.80 | 73.60 | 99.50 | 84.60 | - | - | - |
| **Proposed (CyberGuard-AI)** | **99.99** | **99.99** | **99.99** | **99.99** | **99.99** | **0.01** | **0.01** |

### Table 3: Comparative Evaluation on Dataset 3 (CSE-CIC-IDS2018)
| Model | Accuracy (%) | Precision (%) | Recall (%) | F1-Score (%) | TNR (%) | FPR (%) | FNR (%) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| SHAP | 98.92 | 99.47 | 98.35 | 98.90 | 99.48 | 0.52 | 1.65 |
| DNN | - | 98.99 | 99.04 | 98.71 | - | - | - |
| MLP-PSO | 95.32 | 98.97 | 96.27 | 97.60 | - | 1.03 | 1.03 |
| **Proposed (CyberGuard-AI)** | **98.99** | **99.20** | **99.65** | **99.42** | **99.33** | **0.67** | **0.35** |

*Note: Proposed model achieves an FNR of 0.35% on Dataset 3, substantially lower than MLP-PSO (1.03%) and SHAP (1.65%).*

---

## 🔧 8. Hyperparameter Specifications

| Component | Hyperparameter | Assigned Value | Description |
| :--- | :--- | :---: | :--- |
| **Cross-Modal Attention** | Embedding Dimension (`embed_dim`) | `128` | Latent projection dimension |
| | Attention Heads (`num_heads`) | `4` | Multi-head attention parallelism |
| | Dropout Rate | `0.15` | Regularization preventing overfitting |
| | Optimizer | AdamW (`lr=1e-3`) | Weight decay = `1e-4` |
| | Batch Size / Epochs | `256` / `20` | Mini-batch training with early stopping |
| **DBA Feature Selection** | Number of Agents (`n_agents`) | `15` | Detective behavior population |
| | Iterations (`n_iterations`) | `8` | Global search iterations |
| | Weight Factor (`alpha`) | `0.95` | Trade-off between accuracy and size |
| **FPOA Optimization** | Number of Falcons (`n_falcons`) | `12` | Falco peregrinus swarm size |
| | Max Iterations | `6` | Local exploitation convergence |
| **BKOA Swarm Optimizer** | Number of Kites (`n_kites`) | `10` | Swarm population for XGBoost tuning |
| | Iterations | `8` | Meta-heuristic exploration cycles |
| **XGBoost Meta-Classifier**| Max Depth | `6` | Tree complexity limit |
| | Learning Rate (`eta`) | `0.05` | Gradient shrinkage step |
| | Number of Estimators | `350` | Boosting ensemble size |
| | Subsample / ColSample | `0.85` / `0.80` | Stochastic regularization |

---

## 📄 9. License

This project is licensed under the MIT License - see the `LICENSE` file for details.
