import os
import glob
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import time

def setup_arial_bold_style():
    plt.rcParams['font.sans-serif'] = 'Arial'
    plt.rcParams['font.family'] = 'sans-serif'
    plt.rcParams['font.weight'] = 'bold'
    plt.rcParams['axes.labelweight'] = 'bold'
    plt.rcParams['axes.titleweight'] = 'bold'
    plt.rcParams['xtick.labelsize'] = 18
    plt.rcParams['ytick.labelsize'] = 18
    plt.rcParams['axes.labelsize'] = 20
    plt.rcParams['legend.fontsize'] = 16
    sns.set_theme(style="white")

def apply_borders_and_remove_grid(fig):
    for ax in fig.get_axes():
        ax.grid(False)
        for spine in ['top', 'bottom', 'left', 'right']:
            ax.spines[spine].set_visible(True)
            ax.spines[spine].set_color('black')
            ax.spines[spine].set_linewidth(1.5)

def clean_str(s):
    return str(s).encode('ascii', 'ignore').decode('ascii').strip()

def load_and_preprocess_dataset3(ds_dir=None, output_dir=None, max_train_samples=300000, max_test_samples=50000, force_recompute=False):
    """
    Step 1: Adaptive Data Preprocessing & Normalization for Dataset 3 (CSE-CIC-IDS2018 Intrusion Benchmark).
    - Reads and merges 10 official CSV network flow benchmark files.
    - Explicitly categorizes all 14 attack class names (LOIC-HTTP, HOIC, Hulk, Bot, SSH-Bruteforce, Infiltration, GoldenEye, Slowloris, LOIC-UDP, Web, SQL Injection, Heartbleed).
    - Joins all attack types into 'MALWARE / THREAT (Class 1)' vs 'BENIGN TRAFFIC (Class 0)'.
    - Cleans infinite / NaN network flow values.
    - Applies Log1p transformation for heavy-tailed flow features.
    - Normalizes feature vectors using MinMaxScaler [0, 1].
    - Saves step1 summary to Excel (.xlsx) & CSV (.csv) and distribution plot (800 DPI) in step1_preprocessing subfolder.
    - Saves binary numpy array caches to disk for instant loading by subsequent steps.
    """
    print("=" * 70)
    print("STEP 1: ADAPTIVE DATA PREPROCESSING & NORMALIZATION (DATASET 3 - CSE-CIC-IDS2018)")
    print("=" * 70)
    t0 = time.time()

    if ds_dir is None:
        ds_dir = r"e:\works\project2\dataset3\dataset"
    if output_dir is None:
        output_dir = r"e:\works\project2\dataset3\outputs\step1_preprocessing"

    os.makedirs(output_dir, exist_ok=True)
    setup_arial_bold_style()

    cache_tr_x = os.path.join(output_dir, "X_train_clean.npy")
    cache_tr_y = os.path.join(output_dir, "y_train_clean.npy")
    cache_te_x = os.path.join(output_dir, "X_test_clean.npy")
    cache_te_y = os.path.join(output_dir, "y_test_clean.npy")
    cache_vf   = os.path.join(output_dir, "valid_features.npy")

    if not force_recompute and all(os.path.exists(p) for p in [cache_tr_x, cache_tr_y, cache_te_x, cache_te_y, cache_vf]):
        print(f"Loading preprocessed Dataset 3 directly from disk cache ({output_dir})...")
        X_train = np.load(cache_tr_x)
        y_train = np.load(cache_tr_y)
        X_test  = np.load(cache_te_x)
        y_test  = np.load(cache_te_y)
        valid_features = np.load(cache_vf)
        scaler = MinMaxScaler().fit(X_train)
        print(f"Step 1 Disk Cache Loaded! Shapes: Train {X_train.shape}, Test {X_test.shape} (Took {time.time()-t0:.2f}s)\n")
        return X_train, y_train, X_test, y_test, scaler, valid_features

    # Read official CSV files only
    csv_files = glob.glob(os.path.join(ds_dir, "*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No CSV dataset files found in {ds_dir}")

    print(f"Merging {len(csv_files)} official CSV network flow benchmark files (memory-optimized)...")
    dfs = []
    class_counts = {}
    total_raw_records = 0

    for f in csv_files:
        try:
            df_sub = pd.read_csv(f, low_memory=False)
            total_raw_records += len(df_sub)
            df_sub.columns = [c.strip() for c in df_sub.columns]
            
            label_col = 'Label'
            if label_col not in df_sub.columns:
                possible_labels = [c for c in df_sub.columns if 'label' in c.lower()]
                label_col = possible_labels[0]

            sub_counts = df_sub[label_col].astype(str).str.strip().value_counts()
            for k, v in sub_counts.items():
                class_counts[k] = class_counts.get(k, 0) + v

            if len(df_sub) > 50000:
                df_sub = df_sub.sample(n=50000, random_state=42)

            dfs.append(df_sub)
            print(f"  - Loaded & Sampled {os.path.basename(f)}: {len(df_sub):,d} records")
        except Exception as e:
            print(f"Warning: Failed to read {f}: {e}")

    full_df = pd.concat(dfs, ignore_index=True)
    print(f"\nTotal merged sample pool: {len(full_df):,d} rows, {len(full_df.columns)} columns.")

    label_col = 'Label'
    if label_col not in full_df.columns:
        label_col = [c for c in full_df.columns if 'label' in c.lower()][0]

    raw_labels = full_df[label_col].astype(str).str.strip()

    print("\n--- Dataset 3 Multi-Class Attack Breakdown (Joined into 2 Classes) ---")
    for cls_name, count in class_counts.items():
        clean_cls = clean_str(cls_name)
        target_class = "BENIGN (Class 0)" if "BENIGN" in clean_cls.upper() else "MALWARE / THREAT (Class 1)"
        print(f"  - {clean_cls}: {count:,d} records  --> {target_class}")
    print("------------------------------------------------------------------------\n")

    # Map Binary Labels: BENIGN -> 0, any Intrusion Attack -> 1
    y_raw = np.where(raw_labels.str.upper().str.contains('BENIGN'), 0, 1)

    feature_cols = [c for c in full_df.columns if c != label_col and c not in ['Timestamp', 'Flow ID', 'Source IP', 'Destination IP', 'Source Port', 'Destination Port', 'Dst IP', 'Src IP', 'Dst Port', 'Src Port']]
    
    X_list = []
    for col in feature_cols:
        col_vals = pd.to_numeric(full_df[col], errors='coerce').fillna(0.0).values.astype(np.float32)
        X_list.append(col_vals)

    X_raw = np.column_stack(X_list)
    num_orig_features = X_raw.shape[1]

    # Clean NaN and Infinite values
    X_raw = np.nan_to_num(X_raw, nan=0.0, posinf=0.0, neginf=0.0)

    # Train / Test split
    X_tr_raw, X_te_raw, y_tr_all, y_te_all = train_test_split(
        X_raw, y_raw, test_size=0.20, random_state=42, stratify=y_raw
    )

    if max_train_samples and len(X_tr_raw) > max_train_samples:
        np.random.seed(42)
        tr_idx = np.random.choice(len(X_tr_raw), size=max_train_samples, replace=False)
        X_tr_raw = X_tr_raw[tr_idx]
        y_train = y_tr_all[tr_idx]
    else:
        y_train = y_tr_all

    if max_test_samples and len(X_te_raw) > max_test_samples:
        np.random.seed(42)
        te_idx = np.random.choice(len(X_te_raw), size=max_test_samples, replace=False)
        X_te_raw = X_te_raw[te_idx]
        y_test = y_te_all[te_idx]
    else:
        y_test = y_te_all

    # Log-transformed raw feature distribution for smooth, beautiful plot
    raw_sample_feat = np.log1p(np.maximum(0, X_tr_raw[:, 0]))

    # Apply Log1p transformation
    X_train = np.log1p(np.maximum(0, X_tr_raw))
    X_test  = np.log1p(np.maximum(0, X_te_raw))

    # Remove constant zero-variance features
    feat_std = np.std(X_train, axis=0)
    non_constant = feat_std > 1e-6
    valid_features = np.where(non_constant)[0]

    X_train = X_train[:, valid_features]
    X_test  = X_test[:, valid_features]
    print(f"Features cleaned: Reduced from {num_orig_features} to {len(valid_features)} non-constant features.")

    # MinMaxScaler [0, 1]
    scaler = MinMaxScaler(feature_range=(0, 1))
    X_train = scaler.fit_transform(X_train)
    X_test  = scaler.transform(X_test)

    norm_sample_feat = X_train[:, 0].copy()

    # Save cache arrays to disk
    np.save(cache_tr_x, X_train)
    np.save(cache_tr_y, y_train)
    np.save(cache_te_x, X_test)
    np.save(cache_te_y, y_test)
    np.save(cache_vf, valid_features)
    print(f"Saved Step 1 array caches to disk ({output_dir}).")

    elapsed = time.time() - t0

    # Save Beautiful Smooth Continuous Feature Distribution Plot (Step 1, Fig 7,6, 800 DPI, labelsize=20, ticksize=18)
    fig, ax = plt.subplots(figsize=(7, 6), dpi=800)
    sns.kdeplot(raw_sample_feat, fill=True, color='#e41a1c', label='Raw Feature Range', lw=2.5, ax=ax)
    sns.kdeplot(norm_sample_feat, fill=True, color='#377eb8', label='Normalized Range [0, 1]', lw=2.5, ax=ax)
    ax.set_xlabel('Feature Value Range', fontsize=20, weight='bold', family='Arial')
    ax.set_ylabel('Density', fontsize=20, weight='bold', family='Arial')
    ax.tick_params(axis='both', which='major', labelsize=18)
    ax.legend(frameon=True, fontsize=16)

    apply_borders_and_remove_grid(fig)
    plt.tight_layout()
    dist_plot_path = os.path.join(output_dir, "feature_distribution_before_after.png")
    plt.savefig(dist_plot_path, dpi=800)
    plt.close()
    print(f"Saved Step 1 plot (800 DPI): {dist_plot_path}")

    # Save Step 1 Excel & CSV reports
    summary_rows = [
        {'Parameter': 'Original Feature Count', 'Value': num_orig_features},
        {'Parameter': 'Non-Constant Features Cleaned', 'Value': len(valid_features)},
        {'Parameter': 'Removed Zero-Variance Features', 'Value': num_orig_features - len(valid_features)},
        {'Parameter': 'Total Raw CSV Flow Records', 'Value': total_raw_records},
        {'Parameter': 'Sampled Training Subset', 'Value': len(y_train)},
        {'Parameter': 'Train Benign Count (Class 0)', 'Value': int(np.sum(y_train == 0))},
        {'Parameter': 'Train Malware/Threat Count (Class 1)', 'Value': int(np.sum(y_train == 1))},
        {'Parameter': 'Sampled Testing Subset', 'Value': len(y_test)},
        {'Parameter': 'Test Benign Count (Class 0)', 'Value': int(np.sum(y_test == 0))},
        {'Parameter': 'Test Malware/Threat Count (Class 1)', 'Value': int(np.sum(y_test == 1))},
        {'Parameter': 'Preprocessing Technique', 'Value': 'Log1p + MinMaxScaler [0, 1]'},
        {'Parameter': 'Execution Time (sec)', 'Value': f"{elapsed:.2f}"}
    ]

    for cls_name, count in class_counts.items():
        clean_cls = clean_str(cls_name)
        target_class = "BENIGN (Class 0)" if "BENIGN" in clean_cls.upper() else "MALWARE / THREAT (Class 1)"
        summary_rows.append({'Parameter': f"Joined Attack Class: {clean_cls}", 'Value': f"{count:,d} records -> {target_class}"})

    summary_df = pd.DataFrame(summary_rows)

    csv_path = os.path.join(output_dir, "step1_dataset_summary.csv")
    xlsx_path = os.path.join(output_dir, "step1_dataset_summary.xlsx")

    try:
        summary_df.to_csv(csv_path, index=False)
        print(f"Saved Step 1 CSV report  : {csv_path}")
    except PermissionError:
        print(f"Note: {csv_path} is currently open in Excel. Skipping CSV overwrite.")

    try:
        summary_df.to_excel(xlsx_path, index=False)
        print(f"Saved Step 1 Excel report: {xlsx_path}")
    except PermissionError:
        print(f"Note: {xlsx_path} is currently open in Excel. Skipping Excel overwrite.")

    print(f"Step 1 Complete! Shapes: Train {X_train.shape}, Test {X_test.shape} (Took {elapsed:.2f}s)\n")

    return X_train, y_train, X_test, y_test, scaler, valid_features

if __name__ == "__main__":
    load_and_preprocess_dataset3()
