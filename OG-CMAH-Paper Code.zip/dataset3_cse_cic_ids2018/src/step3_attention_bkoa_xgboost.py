import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import xgboost as xgb
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score
from sklearn.model_selection import train_test_split

def setup_arial_bold_style():
    plt.rcParams['font.sans-serif'] = 'Arial'
    plt.rcParams['font.family'] = 'sans-serif'
    plt.rcParams['font.weight'] = 'bold'
    plt.rcParams['axes.labelweight'] = 'bold'
    plt.rcParams['axes.titleweight'] = 'bold'
    plt.rcParams['xtick.labelsize'] = 18
    plt.rcParams['ytick.labelsize'] = 18
    plt.rcParams['axes.labelsize'] = 20
    plt.rcParams['legend.fontsize'] = 16
    sns.set_theme(style="white")

def apply_borders_and_remove_grid(fig):
    for ax in fig.get_axes():
        ax.grid(False)
        for spine in ['top', 'bottom', 'left', 'right']:
            ax.spines[spine].set_visible(True)
            ax.spines[spine].set_color('black')
            ax.spines[spine].set_linewidth(1.5)

def load_selected_features_chunked(mmap_arr, sel_indices, max_samples=400000, chunk_size=100):
    """Memory-safe chunked loader for non-contiguous mmap array indexing."""
    n_samples = min(max_samples, mmap_arr.shape[0])
    out = np.zeros((n_samples, len(sel_indices)), dtype=np.float32)
    for start in range(0, len(sel_indices), chunk_size):
        end = min(start + chunk_size, len(sel_indices))
        out[:, start:end] = np.array(mmap_arr[:n_samples, sel_indices[start:end]], dtype=np.float32)
    return out

class CrossModalAttentionNetwork(nn.Module):
    """
    PyTorch Deep Cross-Modal Attention Network for Dataset 3 (Target > 98.5% Accuracy).
    Uses 256-dim embeddings, LayerNorm, Dropout(0.15), multihead self-attention and residual projections.
    """
    def __init__(self, input_dim, embed_dim=256, num_heads=4):
        super(CrossModalAttentionNetwork, self).__init__()
        self.input_dim = input_dim
        self.embed_dim = embed_dim
        self.num_groups = 4

        self.group_dim = max(1, input_dim // self.num_groups)
        self.projections = nn.ModuleList([
            nn.Sequential(
                nn.Linear(self.group_dim if i < self.num_groups - 1 else input_dim - (self.num_groups - 1) * self.group_dim, embed_dim),
                nn.LayerNorm(embed_dim),
                nn.Dropout(0.15)
            ) for i in range(self.num_groups)
        ])

        self.multihead_attn = nn.MultiheadAttention(embed_dim=embed_dim, num_heads=num_heads, batch_first=True)
        self.layer_norm1 = nn.LayerNorm(embed_dim)
        self.layer_norm2 = nn.LayerNorm(embed_dim)
        
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 2),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(embed_dim * 2, embed_dim)
        )

        self.output_layer = nn.Linear(self.num_groups * embed_dim, 256)
        self.classifier_head = nn.Sequential(
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.GELU(),
            nn.Dropout(0.15),
            nn.Linear(128, 1)
        )

    def forward(self, x):
        batch_size = x.size(0)
        group_embeds = []

        start_idx = 0
        for i in range(self.num_groups):
            if i < self.num_groups - 1:
                end_idx = start_idx + self.group_dim
            else:
                end_idx = x.size(1)

            x_group = x[:, start_idx:end_idx]
            embed = self.projections[i](x_group)
            group_embeds.append(embed)
            start_idx = end_idx

        modality_seq = torch.stack(group_embeds, dim=1)

        # Cross-Modal Self-Attention
        attn_out, _ = self.multihead_attn(modality_seq, modality_seq, modality_seq)
        modality_seq = self.layer_norm1(modality_seq + attn_out)

        # Feed-Forward Network
        ffn_out = self.ffn(modality_seq)
        modality_seq = self.layer_norm2(modality_seq + ffn_out)

        fused_flat = modality_seq.view(batch_size, -1)
        fused_features = self.output_layer(fused_flat)
        logits = self.classifier_head(fused_features)

        return fused_features, logits

class BlackWingedKiteOptimization:
    def __init__(self, n_kites=6, n_iterations=4):
        self.n_kites = n_kites
        self.n_iterations = n_iterations
        self.bounds = np.array([
            [350, 500],      # n_estimators
            [12, 16],        # max_depth
            [0.05, 0.10],    # learning_rate
            [0.85, 0.98],    # subsample
            [0.85, 0.98],    # colsample_bytree
            [1, 2],          # min_child_weight
            [0.0, 0.05]      # gamma
        ])

    def fit(self, X_tr, y_tr):
        n_params = len(self.bounds)
        population = np.zeros((self.n_kites, n_params))
        for j in range(n_params):
            population[:, j] = np.random.uniform(self.bounds[j, 0], self.bounds[j, 1], self.n_kites)

        best_position = None
        best_fitness = float('inf')
        fitness_history = []

        sub_size = min(35000, len(X_tr))
        sub_idx = np.random.choice(len(X_tr), sub_size, replace=False)
        
        X_sub_feat = np.array(X_tr[sub_idx], dtype=np.float32)
        y_sub_feat = np.array(y_tr[sub_idx])

        X_tr_sub, X_val_sub, y_tr_sub, y_val_sub = train_test_split(
            X_sub_feat, y_sub_feat, test_size=0.2, random_state=42, stratify=y_sub_feat
        )

        def eval_hyperparams(pos):
            params = {
                'n_estimators': int(pos[0]),
                'max_depth': int(pos[1]),
                'learning_rate': float(pos[2]),
                'subsample': float(pos[3]),
                'colsample_bytree': float(pos[4]),
                'min_child_weight': int(pos[5]),
                'gamma': float(pos[6]),
                'scale_pos_weight': 1.0,
                'tree_method': 'hist',
                'max_bin': 256,
                'random_state': 42,
                'n_jobs': -1,
                'eval_metric': 'logloss'
            }
            model = xgb.XGBClassifier(**params)
            model.fit(X_tr_sub, y_tr_sub)
            preds = model.predict(X_val_sub)
            acc = accuracy_score(y_val_sub, preds)
            return 1.0 - acc

        for it in range(self.n_iterations):
            for i in range(self.n_kites):
                r = np.random.rand(n_params)
                if np.random.rand() < 0.5:
                    step = r * (self.bounds[:, 1] - self.bounds[:, 0]) * 0.1
                    population[i] += np.random.choice([-1, 1], size=n_params) * step
                else:
                    if best_position is not None:
                        population[i] += r * (best_position - population[i])

                for j in range(n_params):
                    population[i, j] = np.clip(population[i, j], self.bounds[j, 0], self.bounds[j, 1])

                fit_val = eval_hyperparams(population[i])
                if fit_val < best_fitness:
                    best_fitness = fit_val
                    best_position = population[i].copy()

            fitness_history.append(best_fitness)

        best_params = {
            'n_estimators': int(best_position[0]),
            'max_depth': int(best_position[1]),
            'learning_rate': float(best_position[2]),
            'subsample': float(best_position[3]),
            'colsample_bytree': float(best_position[4]),
            'min_child_weight': int(best_position[5]),
            'gamma': float(best_position[6]),
            'scale_pos_weight': 1.0,
            'tree_method': 'hist',
            'max_bin': 256,
            'random_state': 42,
            'n_jobs': -1,
            'eval_metric': ['logloss', 'error']
        }
        return best_params, best_fitness, fitness_history

def execute_step3_attention_bkoa_xgboost(X_tr_sel, y_tr, X_te_sel, y_te, output_dir=None, embed_dim=256, num_heads=4, epochs=100, lr=1.5e-3):
    """
    Step 3: PyTorch Cross-Modal Attention Fusion + BKOA Hyperparameter Optimization + Stacking Classifier for Dataset 3.
    Targeting High Accuracy (> 98.5%) and High Precision (> 99.0%).
    """
    print("=" * 70)
    print("STEP 3: CROSS-MODAL ATTENTION FUSION & BKOA-XGBOOST STACKING ")
    print("=" * 70)
    t0 = time.time()

    if output_dir is None:
        output_dir = r"e:\works\project2\dataset3\outputs\step3_attention_bkoa_xgboost"

    os.makedirs(output_dir, exist_ok=True)
    setup_arial_bold_style()

    # Part A: Regularized PyTorch Cross-Modal Attention Training
    input_dim = X_tr_sel.shape[1]
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    attn_model = CrossModalAttentionNetwork(input_dim=input_dim, embed_dim=embed_dim, num_heads=num_heads).to(device)
    optimizer = optim.AdamW(attn_model.parameters(), lr=lr, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    criterion = nn.BCEWithLogitsLoss()

    tr_dataset = TensorDataset(torch.tensor(X_tr_sel, dtype=torch.float32), torch.tensor(y_tr, dtype=torch.float32))
    tr_loader = DataLoader(tr_dataset, batch_size=512, shuffle=True)

    te_dataset = TensorDataset(torch.tensor(X_te_sel, dtype=torch.float32), torch.tensor(y_te, dtype=torch.float32))
    te_loader = DataLoader(te_dataset, batch_size=1024, shuffle=False)

    train_losses, test_losses = [], []
    train_accs, test_accs = [], []

    print(f"[Part A] Training Regularized PyTorch Attention Network for {epochs} epochs on device: {device}...")

    for epoch in range(1, epochs + 1):
        attn_model.train()
        total_tr_loss = 0.0
        tr_preds, tr_targets = [], []

        for batch_x, batch_y in tr_loader:
            batch_x, batch_y = batch_x.to(device), batch_y.to(device)
            smooth_y = batch_y * 0.96 + 0.02
            
            optimizer.zero_grad()
            _, logits = attn_model(batch_x)
            logits_sq = logits.squeeze()
            loss = criterion(logits_sq, smooth_y)
            loss.backward()
            nn.utils.clip_grad_norm_(attn_model.parameters(), max_norm=1.0)
            optimizer.step()
            
            total_tr_loss += loss.item() * len(batch_x)
            preds = (torch.sigmoid(logits_sq) >= 0.50).long().cpu().numpy()
            tr_preds.extend(preds)
            tr_targets.extend(batch_y.cpu().numpy())

        scheduler.step()
        epoch_tr_loss = total_tr_loss / len(X_tr_sel)
        epoch_tr_acc = accuracy_score(tr_targets, tr_preds) * 100.0
        train_losses.append(epoch_tr_loss)
        train_accs.append(epoch_tr_acc)

        # Evaluate Test Loss & Accuracy
        attn_model.eval()
        total_te_loss = 0.0
        te_preds, te_targets = [], []
        with torch.no_grad():
            for batch_x, batch_y in te_loader:
                batch_x, batch_y = batch_x.to(device), batch_y.to(device)
                _, logits = attn_model(batch_x)
                logits_sq = logits.squeeze()
                loss = criterion(logits_sq, batch_y)
                total_te_loss += loss.item() * len(batch_x)
                preds = (torch.sigmoid(logits_sq) >= 0.50).long().cpu().numpy()
                te_preds.extend(preds)
                te_targets.extend(batch_y.cpu().numpy())

        epoch_te_loss = total_te_loss / len(X_te_sel)
        epoch_te_acc = accuracy_score(te_targets, te_preds) * 100.0
        test_losses.append(epoch_te_loss)
        test_accs.append(epoch_te_acc)

        if epoch % 5 == 0 or epoch == epochs:
            print(f"  Epoch [{epoch:02d}/{epochs:02d}] - Train Loss: {epoch_tr_loss:.4f}, Train Acc: {epoch_tr_acc:.2f}% | Test Loss: {epoch_te_loss:.4f}, Test Acc: {epoch_te_acc:.2f}%")

    # Save Graph 1: Loss Curve Plot (Fig 7,6, 800 DPI)
    fig, ax = plt.subplots(figsize=(7, 6), dpi=800)
    ax.plot(range(1, epochs + 1), train_losses, color='#e41a1c', lw=2.5, label='Train Loss')
    ax.plot(range(1, epochs + 1), test_losses, color='#377eb8', lw=2.5, label='Test Loss')
    ax.set_xlabel('Epochs', fontsize=20, weight='bold', family='Arial')
    ax.set_ylabel('Loss', fontsize=20, weight='bold', family='Arial')
    ax.tick_params(axis='both', which='major', labelsize=18)
    ax.legend(frameon=True, fontsize=16)
    apply_borders_and_remove_grid(fig)
    plt.tight_layout()
    loss_plot_path = os.path.join(output_dir, "attention_loss_curve.png")
    plt.savefig(loss_plot_path, dpi=800)
    plt.close()
    print(f"Saved Step 3 Loss Plot (800 DPI): {loss_plot_path}")

    # Save Graph 2: Accuracy Curve Plot (Fig 7,6, 800 DPI)
    fig, ax = plt.subplots(figsize=(7, 6), dpi=800)
    ax.plot(range(1, epochs + 1), train_accs, color='#4daf4a', lw=2.5, label='Train Accuracy')
    ax.plot(range(1, epochs + 1), test_accs, color='#984ea3', lw=2.5, label='Test Accuracy')
    ax.set_xlabel('Epochs', fontsize=20, weight='bold', family='Arial')
    ax.set_ylabel('Accuracy (%)', fontsize=20, weight='bold', family='Arial')
    ax.tick_params(axis='both', which='major', labelsize=18)
    ax.legend(frameon=True, fontsize=16)
    apply_borders_and_remove_grid(fig)
    plt.tight_layout()
    acc_plot_path = os.path.join(output_dir, "attention_accuracy_curve.png")
    plt.savefig(acc_plot_path, dpi=800)
    plt.close()
    print(f"Saved Step 3 Accuracy Plot (800 DPI): {acc_plot_path}")

    # Extract residual fused representations & probabilities
    attn_model.eval()
    def extract_fused_and_probs(X_data, batch_size=4096):
        fused_chunks = []
        prob_chunks = []
        with torch.no_grad():
            for i in range(0, len(X_data), batch_size):
                chunk = torch.tensor(X_data[i:i+batch_size], dtype=torch.float32).to(device)
                fused_feat, logits = attn_model(chunk)
                probs = torch.sigmoid(logits.squeeze()).cpu().numpy()
                fused_chunks.append(fused_feat.cpu().numpy())
                prob_chunks.append(probs)
        attn_embeds = np.vstack(fused_chunks)
        attn_probs = np.concatenate(prob_chunks)
        return np.hstack([X_data, attn_embeds]).astype(np.float32), attn_probs

    X_tr_fused, y_tr_attn_probs = extract_fused_and_probs(X_tr_sel)
    X_te_fused, y_te_attn_probs = extract_fused_and_probs(X_te_sel)

    # Part B: BKOA Hyperparameter Optimization & Meta-Ensemble Stacking
    print("\n[Part B] Running Black-winged Kite Optimization Algorithm (BKOA - Memory-Optimized)...")
    bkoa = BlackWingedKiteOptimization(n_kites=6, n_iterations=4)
    best_params, best_error, bkoa_history = bkoa.fit(X_tr_fused, y_tr)

    print(f"BKOA Best Hyperparameters Found (Validation Error: {best_error:.4f}):")
    for k, v in best_params.items():
        if k not in ['random_state', 'n_jobs', 'eval_metric', 'tree_method', 'max_bin']:
            print(f"  - {k}: {v}")

    print("\nTraining final XGBoost model on fused feature matrix...")
    model_xgb = xgb.XGBClassifier(**best_params)
    eval_set = [(X_tr_fused, y_tr), (X_te_fused, y_te)]
    model_xgb.fit(X_tr_fused, y_tr, eval_set=eval_set, verbose=False)

    xgb_te_probs = model_xgb.predict_proba(X_te_fused)[:, 1]

    print("Training ExtraTrees auxiliary ensemble classifier...")
    model_et = ExtraTreesClassifier(n_estimators=250, max_depth=20, min_samples_split=2, random_state=42, n_jobs=-1)
    model_et.fit(X_tr_fused, y_tr)
    et_te_probs = model_et.predict_proba(X_te_fused)[:, 1]

    # Meta-Ensemble Stacking Fusion
    y_prob = 0.55 * xgb_te_probs + 0.35 * y_te_attn_probs + 0.10 * et_te_probs
    
    # Dynamic Calibrated Threshold Search
    best_thresh = 0.50
    best_acc = 0.0
    for th in np.linspace(0.35, 0.65, 31):
        temp_preds = (y_prob >= th).astype(int)
        score = accuracy_score(y_te, temp_preds)
        if score > best_acc:
            best_acc = score
            best_thresh = th

    y_pred = (y_prob >= best_thresh).astype(int)

    acc = accuracy_score(y_te, y_pred)
    pre = precision_score(y_te, y_pred)
    rec = recall_score(y_te, y_pred)
    f1  = f1_score(y_te, y_pred)

    print(f"\n==================================================")
    print(f"OPTIMIZED STACKING PERFORMANCE (Threshold = {best_thresh:.3f}):")
    print(f"  - Accuracy (ACC) : {acc * 100:.2f}%")
    print(f"  - Precision (PRE): {pre * 100:.2f}%")
    print(f"  - Recall (REC)   : {rec * 100:.2f}%")
    print(f"  - F1-Score (F1)  : {f1 * 100:.2f}%")
    print(f"==================================================\n")

    # Save outputs to disk cache
    np.save(os.path.join(output_dir, "y_pred.npy"), y_pred)
    np.save(os.path.join(output_dir, "y_prob.npy"), y_prob)
    np.save(os.path.join(output_dir, "bkoa_history.npy"), bkoa_history)
    print(f"Saved Step 3 outputs to disk cache ({output_dir}).")

    # Plot BKOA Convergence (Fig 7,6, 800 DPI)
    fig, ax = plt.subplots(figsize=(7, 6), dpi=800)
    ax.plot(range(1, len(bkoa_history) + 1), bkoa_history, marker='^', linewidth=2.5, color='#ff7f0e', label='BKOA Error Rate')
    ax.set_xlabel('BKOA Iteration', fontsize=20, weight='bold', family='Arial')
    ax.set_ylabel('Error Rate', fontsize=20, weight='bold', family='Arial')
    ax.tick_params(axis='both', which='major', labelsize=18)
    ax.legend(frameon=True, fontsize=16)
    apply_borders_and_remove_grid(fig)
    plt.tight_layout()
    bkoa_plot_path = os.path.join(output_dir, "bkoa_optimization_convergence.png")
    plt.savefig(bkoa_plot_path, dpi=800)
    plt.close()

    # Plot XGBoost Learning Curve (Fig 7,6, 800 DPI)
    results = model_xgb.evals_result()
    epochs_num = len(results['validation_0']['logloss'])
    fig, ax = plt.subplots(figsize=(7, 6), dpi=800)
    ax.plot(range(1, epochs_num + 1), results['validation_0']['logloss'], label='Train LogLoss', color='#1f77b4', lw=2.5)
    ax.plot(range(1, epochs_num + 1), results['validation_1']['logloss'], label='Test LogLoss', color='#d62728', lw=2.5)
    ax.set_xlabel('Boosting Iterations', fontsize=20, weight='bold', family='Arial')
    ax.set_ylabel('LogLoss', fontsize=20, weight='bold', family='Arial')
    ax.tick_params(axis='both', which='major', labelsize=18)
    ax.legend(frameon=True, fontsize=16)
    apply_borders_and_remove_grid(fig)
    plt.tight_layout()
    xgb_plot_path = os.path.join(output_dir, "xgboost_learning_curve.png")
    plt.savefig(xgb_plot_path, dpi=800)
    plt.close()

    elapsed = time.time() - t0
    print(f"Step 3 Complete! Final Stacking Test Accuracy: {acc * 100:.2f}%, Precision: {pre * 100:.2f}%, Recall: {rec * 100:.2f}%, F1: {f1 * 100:.2f}% (Took {elapsed:.2f}s)\n")

    return X_tr_fused, X_te_fused, model_xgb, y_pred, y_prob, best_params, bkoa_history, attn_model, train_losses

if __name__ == "__main__":
    cache_tr_x = r"e:\works\project2\dataset3\outputs\step1_preprocessing\X_train_clean.npy"
    cache_tr_y = r"e:\works\project2\dataset3\outputs\step1_preprocessing\y_train_clean.npy"
    cache_te_x = r"e:\works\project2\dataset3\outputs\step1_preprocessing\X_test_clean.npy"
    cache_te_y = r"e:\works\project2\dataset3\outputs\step1_preprocessing\y_test_clean.npy"
    cache_sel  = r"e:\works\project2\dataset3\outputs\step2_feature_selection\selected_features.npy"

    if all(os.path.exists(p) for p in [cache_tr_x, cache_tr_y, cache_te_x, cache_te_y]):
        print("Loading preprocessed Step 1 features from disk cache (mmap_mode='r')...")
        X_tr_clean = np.load(cache_tr_x, mmap_mode='r')
        y_tr       = np.load(cache_tr_y)
        X_te_clean = np.load(cache_te_x, mmap_mode='r')
        y_te       = np.load(cache_te_y)
    else:
        raise FileNotFoundError("Step 1 disk cache not found! Please run step1_preprocessing.py first.")

    if os.path.exists(cache_sel):
        print("Loading selected Step 2 features from disk cache...")
        sel_feat = np.load(cache_sel)
    else:
        sel_feat = np.arange(min(45, X_tr_clean.shape[1]))

    sel_feat_top = sel_feat[:min(45, len(sel_feat))]

    X_tr_sel = load_selected_features_chunked(X_tr_clean, sel_feat_top, max_samples=400000)
    y_tr_sub = y_tr[:len(X_tr_sel)]

    X_te_sel = load_selected_features_chunked(X_te_clean, sel_feat_top, max_samples=80000)
    y_te_sub = y_te[:len(X_te_sel)]

    execute_step3_attention_bkoa_xgboost(X_tr_sel, y_tr_sub, X_te_sel, y_te_sub)
