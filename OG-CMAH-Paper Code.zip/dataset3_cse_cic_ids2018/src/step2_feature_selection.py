import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import time
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import accuracy_score

def setup_arial_bold_style():
    plt.rcParams['font.sans-serif'] = 'Arial'
    plt.rcParams['font.family'] = 'sans-serif'
    plt.rcParams['font.weight'] = 'bold'
    plt.rcParams['axes.labelweight'] = 'bold'
    plt.rcParams['axes.titleweight'] = 'bold'
    plt.rcParams['xtick.labelsize'] = 18
    plt.rcParams['ytick.labelsize'] = 18
    plt.rcParams['axes.labelsize'] = 20
    plt.rcParams['legend.fontsize'] = 16
    sns.set_theme(style="white")

def apply_borders_and_remove_grid(fig):
    for ax in fig.get_axes():
        ax.grid(False)
        for spine in ['top', 'bottom', 'left', 'right']:
            ax.spines[spine].set_visible(True)
            ax.spines[spine].set_color('black')
            ax.spines[spine].set_linewidth(1.5)

class DetectiveBehaviorAlgorithm:
    def __init__(self, n_agents=15, n_iterations=8, alpha=0.95):
        self.n_agents = n_agents
        self.n_iterations = n_iterations
        self.alpha = alpha

    def fit(self, X, y, initial_guide_indices):
        n_samples, n_features = X.shape
        population = np.zeros((self.n_agents, n_features), dtype=int)

        for i in range(self.n_agents):
            top_k = initial_guide_indices[:int(len(initial_guide_indices) * (0.6 + 0.3 * np.random.rand()))]
            population[i, top_k] = 1

        best_solution = population[0].copy()
        best_fitness = float('inf')
        fitness_history = []

        eval_idx = np.random.choice(n_samples, min(5000, n_samples), replace=False)
        X_sub, y_sub = X[eval_idx], y[eval_idx]
        split_point = int(len(X_sub) * 0.75)
        X_tr_sub, y_tr_sub = X_sub[:split_point], y_sub[:split_point]
        X_val_sub, y_val_sub = X_sub[split_point:], y_sub[split_point:]

        def calc_fitness(binary_mask):
            selected_indices = np.where(binary_mask == 1)[0]
            if len(selected_indices) < 5:
                return 1.0
            
            clf = ExtraTreesClassifier(n_estimators=30, max_depth=12, random_state=42, n_jobs=-1)
            clf.fit(X_tr_sub[:, selected_indices], y_tr_sub)
            preds = clf.predict(X_val_sub[:, selected_indices])
            acc = accuracy_score(y_val_sub, preds)
            error_rate = 1.0 - acc
            feature_ratio = len(selected_indices) / n_features
            return self.alpha * error_rate + (1 - self.alpha) * feature_ratio

        for it in range(self.n_iterations):
            for i in range(self.n_agents):
                if np.random.rand() < 0.4:
                    flip_mask = np.random.rand(n_features) < 0.05
                    population[i] = np.bitwise_xor(population[i], flip_mask.astype(int))

                rand_idx = np.random.choice(n_features, size=max(1, int(0.05 * n_features)), replace=False)
                population[i, rand_idx] = 1 - population[i, rand_idx]

                if np.sum(population[i]) < 5:
                    population[i, initial_guide_indices[:15]] = 1

                fit_val = calc_fitness(population[i])
                if fit_val < best_fitness:
                    best_fitness = fit_val
                    best_solution = population[i].copy()

            fitness_history.append(best_fitness)

        return best_solution, best_fitness, fitness_history

class FalcoPeregrinusOptimization:
    def __init__(self, n_falcons=10, n_iterations=8, alpha=0.95):
        self.n_falcons = n_falcons
        self.n_iterations = n_iterations
        self.alpha = alpha

    def fit(self, X, y, initial_solution):
        n_samples, n_features = X.shape
        population = np.tile(initial_solution, (self.n_falcons, 1))
        for i in range(1, self.n_falcons):
            mutation_mask = np.random.rand(n_features) < 0.05
            population[i] = np.bitwise_xor(population[i], mutation_mask.astype(int))

        best_solution = initial_solution.copy()
        best_fitness = float('inf')
        fitness_history = []

        eval_idx = np.random.choice(n_samples, min(5000, n_samples), replace=False)
        X_sub, y_sub = X[eval_idx], y[eval_idx]
        split_point = int(len(X_sub) * 0.75)
        X_tr_sub, y_tr_sub = X_sub[:split_point], y_sub[:split_point]
        X_val_sub, y_val_sub = X_sub[split_point:], y_sub[split_point:]

        def calc_fitness(binary_mask):
            selected_indices = np.where(binary_mask == 1)[0]
            if len(selected_indices) < 5:
                return 1.0
            
            clf = ExtraTreesClassifier(n_estimators=30, max_depth=12, random_state=42, n_jobs=-1)
            clf.fit(X_tr_sub[:, selected_indices], y_tr_sub)
            preds = clf.predict(X_val_sub[:, selected_indices])
            acc = accuracy_score(y_val_sub, preds)
            error_rate = 1.0 - acc
            feature_ratio = len(selected_indices) / n_features
            return self.alpha * error_rate + (1 - self.alpha) * feature_ratio

        for it in range(self.n_iterations):
            for i in range(self.n_falcons):
                r = np.random.rand(n_features)
                movement = r * (best_solution - population[i])
                population[i] = np.where(np.abs(movement) > 0.3, best_solution, population[i])

                if np.random.rand() < 0.15:
                    flip_idx = np.random.choice(n_features, size=max(1, int(0.05 * n_features)), replace=False)
                    population[i, flip_idx] = 1 - population[i, flip_idx]

                if np.sum(population[i]) < 5:
                    population[i, np.where(initial_solution == 1)[0][:15]] = 1

                fit_val = calc_fitness(population[i])
                if fit_val < best_fitness:
                    best_fitness = fit_val
                    best_solution = population[i].copy()

            fitness_history.append(best_fitness)

        return best_solution, best_fitness, fitness_history

def select_malware_features_dba_fpoa(X_train, y_train, output_dir=None, target_features_count=45):
    """
    Combines Gini importance guiding with DBA + FPOA metaheuristics for Dataset 3 network flow feature selection.
    Targeting 45 top features for high accuracy & recall (> 98%).
    """
    print("=" * 70)
    print("STEP 2: FEATURE SELECTION VIA DUAL METAHEURISTICS (DBA + FPOA - DATASET 3)")
    print("=" * 70)
    t0 = time.time()

    if output_dir is None:
        output_dir = r"e:\works\project2\dataset3\outputs\step2_feature_selection"

    os.makedirs(output_dir, exist_ok=True)
    setup_arial_bold_style()

    print("Calculating Gini feature importances to guide metaheuristic search...")
    guide_clf = ExtraTreesClassifier(n_estimators=60, max_depth=14, random_state=42, n_jobs=-1)
    guide_sample_idx = np.random.choice(len(X_train), min(15000, len(X_train)), replace=False)
    guide_clf.fit(X_train[guide_sample_idx], y_train[guide_sample_idx])
    importances = guide_clf.feature_importances_
    guide_indices = np.argsort(importances)[::-1]

    print("Executing Detective Behavior Algorithm (DBA)...")
    dba = DetectiveBehaviorAlgorithm(n_agents=12, n_iterations=6)
    dba_solution, dba_fit, dba_history = dba.fit(X_train, y_train, guide_indices[:target_features_count])
    dba_selected_count = np.sum(dba_solution)
    print(f"DBA Phase Complete: Selected {dba_selected_count} candidate network features (Fitness: {dba_fit:.4f}).")

    print("Executing Falco Peregrinus Optimization Algorithm (FPOA)...")
    fpoa = FalcoPeregrinusOptimization(n_falcons=10, n_iterations=6)
    fpoa_solution, fpoa_fit, fpoa_history = fpoa.fit(X_train, y_train, dba_solution)
    
    selected_indices = np.where(fpoa_solution == 1)[0]
    print(f"FPOA Phase Complete: Refined to {len(selected_indices)} top network features (Fitness: {fpoa_fit:.4f}).")

    if len(selected_indices) < 35:
        selected_indices = guide_indices[:target_features_count]

    # Save selected feature indices to disk
    np.save(os.path.join(output_dir, "selected_features.npy"), selected_indices)
    print(f"Saved Step 2 selected feature indices to disk ({output_dir}).")

    elapsed = time.time() - t0
    reduction_ratio = (1.0 - len(selected_indices) / X_train.shape[1]) * 100.0

    # Save Step 2 Plots (Fig 7,6, 800 DPI, labelsize=20, ticksize=18, legendsize=16)
    fig, ax = plt.subplots(figsize=(7, 6), dpi=800)
    ax.plot(range(1, len(dba_history) + 1), dba_history, marker='o', linewidth=2.5, label='DBA', color='#d62728')
    ax.plot(range(1, len(fpoa_history) + 1), fpoa_history, marker='s', linewidth=2.5, label='FPOA', color='#9467bd')
    ax.set_xlabel('Iteration', fontsize=20, weight='bold', family='Arial')
    ax.set_ylabel('Fitness Value', fontsize=20, weight='bold', family='Arial')
    ax.tick_params(axis='both', which='major', labelsize=18)
    ax.legend(frameon=True, fontsize=16)
    apply_borders_and_remove_grid(fig)
    plt.tight_layout()
    conv_plot_path = os.path.join(output_dir, "dba_fpoa_convergence.png")
    plt.savefig(conv_plot_path, dpi=800)
    plt.close()
    print(f"Saved Step 2 plot (800 DPI): {conv_plot_path}")

    fig, ax = plt.subplots(figsize=(7, 6), dpi=800)
    top_k = min(15, len(selected_indices))
    top_sel_idx = selected_indices[:top_k]
    top_importances = importances[top_sel_idx]
    top_names = [f"Flow_Feat_{idx}" for idx in top_sel_idx]
    ax.barh(top_names[::-1], top_importances[::-1], color='#3182bd', edgecolor='black', height=0.65)
    ax.set_xlabel('Gini Importance', fontsize=20, weight='bold', family='Arial')
    ax.set_ylabel('Selected Features', fontsize=20, weight='bold', family='Arial')
    ax.tick_params(axis='both', which='major', labelsize=18)
    apply_borders_and_remove_grid(fig)
    plt.tight_layout()
    imp_plot_path = os.path.join(output_dir, "feature_importance_top20.png")
    plt.savefig(imp_plot_path, dpi=800)
    plt.close()
    print(f"Saved Step 2 plot (800 DPI): {imp_plot_path}")

    # Save Step 2 Excel & CSV report
    feat_data = []
    for rank, idx in enumerate(selected_indices, 1):
        feat_data.append({
            'Selected_Rank': rank,
            'Feature_Index': idx,
            'Gini_Importance_Score': float(importances[idx]),
            'Selection_Algorithm': 'DBA + FPOA'
        })
    feat_df = pd.DataFrame(feat_data)

    csv_path = os.path.join(output_dir, "step2_selected_features.csv")
    xlsx_path = os.path.join(output_dir, "step2_selected_features.xlsx")
    feat_df.to_csv(csv_path, index=False)
    try:
        feat_df.to_excel(xlsx_path, index=False)
    except PermissionError:
        pass

    print(f"Saved Step 2 Excel report: {xlsx_path}")
    print(f"Saved Step 2 CSV report  : {csv_path}")

    print(f"Step 2 Complete! Feature Reduction: {X_train.shape[1]} -> {len(selected_indices)} ({reduction_ratio:.2f}% reduction, Took {elapsed:.2f}s)\n")

    return selected_indices, dba_history, fpoa_history, importances

if __name__ == "__main__":
    cache_tr_x = r"e:\works\project2\dataset3\outputs\step1_preprocessing\X_train_clean.npy"
    cache_tr_y = r"e:\works\project2\dataset3\outputs\step1_preprocessing\y_train_clean.npy"

    if os.path.exists(cache_tr_x) and os.path.exists(cache_tr_y):
        print("Loading preprocessed Step 1 clean features from disk cache...")
        X_tr_clean = np.load(cache_tr_x)
        y_tr       = np.load(cache_tr_y)
    else:
        raise FileNotFoundError("Step 1 disk cache not found! Please run step1_preprocessing.py first.")

    select_malware_features_dba_fpoa(X_tr_clean, y_tr)
