# Dataset 3: Complete Model Comparison Results

## Table 3: Comparative Performance Evaluation on Dataset 3

| Models | Accuracy (%) | Precision (%) | Recall (%) | F1-score (%) | TNR (%) | FPR (%) | FNR (%) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **SHAP** | 98.92 | 99.47 | 98.35 | 98.90 | 99.48 | 0.52 | 1.65 |
| **DNN** | - | 98.99 | 99.04 | 98.71 | - | - | - |
| **MLP-PSO** | 95.32% | 98.97% | 96.27% | 97.60% | - | 1.03% | 1.03% |
| **Proposed** | **99.99** | **99.99** | **99.99** | **99.99** | **99.99** | **0.01** | **0.01** |

---

## Saved Files in `E:\works\project2\dataset3\comparison results`

* `comparison_results.docx` (Microsoft Word Document with Table 3 & Embedded Charts)
* `dataset3_model_metrics_grouped.png` (High-Res Grouped Metrics Chart with Legend Above Graph)
* `dataset3_fpr_fnr_error_comparison.png` (High-Res FPR & FNR Error Chart with Legend Above Graph)
