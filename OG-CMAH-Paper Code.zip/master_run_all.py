"""
========================================================================================
   CYBERGUARD-AI: MASTER JOURNAL REPRODUCIBILITY & PIPELINE RUNNER
========================================================================================
This script provides a unified interface to execute the end-to-end evaluation pipelines
for Dataset 1 (EMBER 2018), Dataset 2 (CIC-IDS2017), Dataset 3 (CSE-CIC-IDS2018),
and launch the Real-Time SOC Threat Dashboard.

Usage:
    python master_run_all.py --help
    python master_run_all.py --dataset 1      # Run Dataset 1 pipeline
    python master_run_all.py --dataset 2      # Run Dataset 2 pipeline
    python master_run_all.py --dataset 3      # Run Dataset 3 pipeline
    python master_run_all.py --dashboard      # Start Flask SOC Dashboard
    python master_run_all.py --all            # Run all 3 dataset pipelines consecutively
========================================================================================
"""

import os
import sys
import argparse
import subprocess
import time

def print_header(title):
    print("\n" + "=" * 80)
    print(f"   {title}")
    print("=" * 80 + "\n")

def run_dataset_pipeline(dataset_num):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    folders = {
        1: ("dataset1_ember_malware", "run_dataset1_pipeline.py", "Dataset 1 (EMBER 2018 Malware PE)"),
        2: ("dataset2_cic_ids2017", "run_dataset2_pipeline.py", "Dataset 2 (CIC-IDS2017 Intrusion)"),
        3: ("dataset3_cse_cic_ids2018", "run_dataset3_pipeline.py", "Dataset 3 (CSE-CIC-IDS2018 Intrusion)")
    }
    
    if dataset_num not in folders:
        print(f"[ERROR] Invalid dataset index: {dataset_num}. Choose 1, 2, or 3.")
        return False

    folder_name, script_name, desc = folders[dataset_num]
    script_path = os.path.join(base_dir, folder_name, script_name)

    if not os.path.exists(script_path):
        print(f"[ERROR] Script not found: {script_path}")
        return False

    print_header(f"EXECUTING PIPELINE: {desc}")
    t0 = time.time()
    result = subprocess.run([sys.executable, script_path], cwd=os.path.join(base_dir, folder_name))
    elapsed = time.time() - t0

    if result.returncode == 0:
        print(f"\n[SUCCESS] {desc} finished successfully in {elapsed:.2f} seconds.")
        return True
    else:
        print(f"\n[ERROR] Pipeline failed with return code {result.returncode}.")
        return False

def launch_web_dashboard():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dash_script = os.path.join(base_dir, "web_dashboard", "app.py")
    
    if not os.path.exists(dash_script):
        print(f"[ERROR] Dashboard script not found: {dash_script}")
        return

    print_header("LAUNCHING CYBERGUARD-AI REAL-TIME SOC DASHBOARD")
    print("Dashboard listening at: http://127.0.0.1:5000")
    print("Press CTRL+C to terminate.")
    subprocess.run([sys.executable, dash_script], cwd=os.path.join(base_dir, "web_dashboard"))

def main():
    parser = argparse.ArgumentParser(
        description="CyberGuard-AI: Master Journal Pipeline Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Example: python master_run_all.py --dataset 3"
    )
    parser.add_argument("--dataset", type=int, choices=[1, 2, 3], help="Execute a specific dataset pipeline (1, 2, or 3)")
    parser.add_argument("--all", action="store_true", help="Execute all 3 dataset pipelines consecutively")
    parser.add_argument("--dashboard", action="store_true", help="Launch the Flask Real-Time Threat Intelligence Dashboard")

    args = parser.parse_args()

    if len(sys.argv) == 1:
        print_header("CYBERGUARD-AI REPRODUCIBILITY MENU")
        print("1. Run Dataset 1 Pipeline (EMBER 2018)")
        print("2. Run Dataset 2 Pipeline (CIC-IDS2017)")
        print("3. Run Dataset 3 Pipeline (CSE-CIC-IDS2018)")
        print("4. Launch Web SOC Threat Dashboard")
        print("5. Run All 3 Pipelines Consecutively")
        print("0. Exit")
        try:
            choice = input("\nEnter your selection (0-5): ").strip()
            if choice == "1": run_dataset_pipeline(1)
            elif choice == "2": run_dataset_pipeline(2)
            elif choice == "3": run_dataset_pipeline(3)
            elif choice == "4": launch_web_dashboard()
            elif choice == "5":
                for d in [1, 2, 3]: run_dataset_pipeline(d)
            elif choice == "0": sys.exit(0)
            else: print("Invalid selection.")
        except KeyboardInterrupt:
            print("\nExiting.")
            sys.exit(0)
        return

    if args.dataset:
        run_dataset_pipeline(args.dataset)
    elif args.all:
        for d in [1, 2, 3]:
            success = run_dataset_pipeline(d)
            if not success:
                print(f"[WARNING] Stopping execution due to error in dataset {d}.")
                break
    elif args.dashboard:
        launch_web_dashboard()

if __name__ == "__main__":
    main()
